<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 1: Validate Environment & Permissions
.DESCRIPTION
    Validates dv_config.json, connects to Dataverse via GCC endpoint,
    verifies System Administrator role, checks for existing publisher/solution,
    and exports a baseline inventory.
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\01_validate_dataverse.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 1: Validate" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor Cyan

# ── Load config ──
$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url
$issues = @()

# ── Check placeholders ──
Write-Host "  Checking for PLACEHOLDER values..." -ForegroundColor White
$raw = Get-Content $ConfigPath -Raw
$placeholders = [regex]::Matches($raw, 'PLACEHOLDER[A-Z_]*')
if ($placeholders.Count -gt 0) {
    $unique = $placeholders | ForEach-Object { $_.Value } | Sort-Object -Unique
    foreach ($p in $unique) {
        Write-Host "    [FAIL] Unreplaced: $p" -ForegroundColor Red
        $issues += "Unreplaced placeholder: $p"
    }
} else {
    Write-Host "    [PASS] No placeholders found" -ForegroundColor Green
}

# ── Validate URL format ──
Write-Host "`n  Checking environment URL format..." -ForegroundColor White
if ($envUrl -match "\.crm9\.dynamics\.com") {
    Write-Host "    [PASS] GCC endpoint confirmed (.crm9)" -ForegroundColor Green
} elseif ($envUrl -match "\.crm\.dynamics\.com") {
    Write-Host "    [WARN] Commercial endpoint detected (.crm) - expected .crm9 for GCC" -ForegroundColor Yellow
    $issues += "URL appears to be commercial, not GCC"
} elseif ($envUrl -match "\.crm9\.dynamics\.us") {
    Write-Host "    [PASS] GCC High endpoint confirmed (.crm9.dynamics.us)" -ForegroundColor Green
} else {
    Write-Host "    [WARN] Unrecognized endpoint: $envUrl" -ForegroundColor Yellow
}

# ── Validate required fields ──
Write-Host "`n  Checking required fields..." -ForegroundColor White
@(
    @{n="environment.url";        v=$config.environment.url},
    @{n="environment.id";         v=$config.environment.id},
    @{n="environment.tenant_id";  v=$config.environment.tenant_id},
    @{n="admin.upn";              v=$config.admin.upn},
    @{n="publisher.prefix";       v=$config.publisher.prefix},
    @{n="solution.unique_name";   v=$config.solution.unique_name}
) | ForEach-Object {
    if ([string]::IsNullOrWhiteSpace($_.v)) {
        Write-Host "    [FAIL] Empty: $($_.n)" -ForegroundColor Red
        $issues += "Empty: $($_.n)"
    } else {
        Write-Host "    [PASS] $($_.n) = $($_.v)" -ForegroundColor Green
    }
}

# ── Validate publisher prefix ──
Write-Host "`n  Checking naming convention..." -ForegroundColor White
$prefix = $config.publisher.prefix
if ($prefix -ceq $prefix.ToLower() -and $prefix -match '^[a-z][a-z0-9]*$') {
    Write-Host "    [PASS] Prefix '$prefix' is lowercase alphanumeric" -ForegroundColor Green
} else {
    Write-Host "    [FAIL] Prefix '$prefix' should be lowercase letters/numbers only" -ForegroundColor Red
    $issues += "Publisher prefix must be lowercase"
}

# ── Connect to Dataverse ──
Write-Host "`n  Connecting to Dataverse: $envUrl" -ForegroundColor White
Write-Host "    Using interactive auth (CAC will be prompted)..." -ForegroundColor Gray

try {
    $conn = Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth
    
    if ($conn.IsReady) {
        Write-Host "    [PASS] Connected to: $($conn.ConnectedOrgFriendlyName)" -ForegroundColor Green
        Write-Host "    Org ID: $($conn.ConnectedOrgId)" -ForegroundColor Gray
        Write-Host "    Org Name: $($conn.ConnectedOrgUniqueName)" -ForegroundColor Gray
    } else {
        Write-Host "    [FAIL] Connection not ready" -ForegroundColor Red
        $issues += "Dataverse connection failed"
    }
} catch {
    Write-Host "    [FAIL] $($_.Exception.Message)" -ForegroundColor Red
    $issues += "Connection error: $($_.Exception.Message)"
    
    Write-Host "`n    TROUBLESHOOTING:" -ForegroundColor Yellow
    Write-Host "    1. Verify CAC is inserted and middleware running" -ForegroundColor White
    Write-Host "    2. Verify URL ends in .crm9.dynamics.com (GCC)" -ForegroundColor White
    Write-Host "    3. Try: pac auth create --url $envUrl" -ForegroundColor White
    Write-Host "    4. Verify System Administrator role in Advanced Settings > Users" -ForegroundColor White
}

if (-not $conn -or -not $conn.IsReady) {
    Write-Host "`n  [STOPPED] Cannot continue without Dataverse connection." -ForegroundColor Red
    return
}

# ── Verify System Administrator role ──
Write-Host "`n  Verifying your security roles..." -ForegroundColor White
try {
    $whoami = Invoke-CrmWhoAmI -conn $conn
    $userId = $whoami.UserId
    Write-Host "    User ID: $userId" -ForegroundColor Gray
    
    $roles = Get-CrmUserSecurityRoles -conn $conn -UserId $userId
    $roleNames = $roles | ForEach-Object { $_.RoleName }
    
    if ("System Administrator" -in $roleNames) {
        Write-Host "    [PASS] System Administrator role confirmed" -ForegroundColor Green
    } else {
        Write-Host "    [FAIL] System Administrator role NOT found" -ForegroundColor Red
        Write-Host "    Your roles: $($roleNames -join ', ')" -ForegroundColor Yellow
        $issues += "Missing System Administrator role"
    }
    
    Write-Host "    All roles: $($roleNames -join ', ')" -ForegroundColor Gray
} catch {
    Write-Host "    [WARN] Could not verify roles: $($_.Exception.Message)" -ForegroundColor Yellow
}

# ── Check for existing publisher ──
Write-Host "`n  Checking for existing CWF publisher..." -ForegroundColor White
try {
    $existingPub = Get-CrmRecords -conn $conn `
        -EntityLogicalName publisher `
        -FilterAttribute customizationprefix `
        -FilterOperator eq `
        -FilterValue $prefix `
        -Fields friendlyname,customizationprefix,customizationoptionvalueprefix `
        -TopCount 5
    
    if ($existingPub.Count -gt 0) {
        $pub = $existingPub.CrmRecords[0]
        Write-Host "    [EXISTS] Publisher found: $($pub.friendlyname) (prefix: $($pub.customizationprefix))" -ForegroundColor DarkYellow
        Write-Host "    Choice value prefix: $($pub.customizationoptionvalueprefix)" -ForegroundColor Gray
        Write-Host "    Publisher already exists - Step 02 will skip creation" -ForegroundColor Gray
    } else {
        Write-Host "    [OK] No existing publisher with prefix '$prefix' - will be created in Step 02" -ForegroundColor Green
    }
} catch {
    Write-Host "    [WARN] Could not check publisher: $($_.Exception.Message)" -ForegroundColor Yellow
}

# ── Check for existing solution ──
Write-Host "`n  Checking for existing CWF solution..." -ForegroundColor White
try {
    $existingSol = Get-CrmRecords -conn $conn `
        -EntityLogicalName solution `
        -FilterAttribute uniquename `
        -FilterOperator eq `
        -FilterValue $config.solution.unique_name `
        -Fields friendlyname,uniquename,version `
        -TopCount 5
    
    if ($existingSol.Count -gt 0) {
        $sol = $existingSol.CrmRecords[0]
        Write-Host "    [EXISTS] Solution found: $($sol.friendlyname) v$($sol.version)" -ForegroundColor DarkYellow
    } else {
        Write-Host "    [OK] No existing solution - will be created in Step 02" -ForegroundColor Green
    }
} catch {
    Write-Host "    [WARN] Could not check solution: $($_.Exception.Message)" -ForegroundColor Yellow
}

# ── Count existing CWF tables ──
Write-Host "`n  Checking for existing CWF tables..." -ForegroundColor White
try {
    $apiUrl = "$envUrl/api/data/v9.2/EntityDefinitions?" +
              "`$filter=startswith(SchemaName,'cwf_')&`$select=SchemaName,DisplayName"
    
    $headers = @{
        "Authorization" = "Bearer $($conn.CurrentAccessToken)"
        "OData-MaxVersion" = "4.0"
        "OData-Version" = "4.0"
    }
    
    $result = Invoke-RestMethod -Uri $apiUrl -Headers $headers -Method Get
    $cwfTables = $result.value
    
    if ($cwfTables.Count -gt 0) {
        Write-Host "    [EXISTS] Found $($cwfTables.Count) CWF tables:" -ForegroundColor DarkYellow
        foreach ($t in $cwfTables) {
            Write-Host "      - $($t.SchemaName)" -ForegroundColor Gray
        }
    } else {
        Write-Host "    [OK] No existing CWF tables - clean environment" -ForegroundColor Green
    }
} catch {
    Write-Host "    [WARN] Could not check tables via API: $($_.Exception.Message)" -ForegroundColor Yellow
}

# ── Export baseline ──
Write-Host "`n  Exporting baseline inventory..." -ForegroundColor White
try {
    $allRoles = Get-CrmRecords -conn $conn -EntityLogicalName role `
        -Fields name,ismanaged,modifiedon -TopCount 200
    $allRoles.CrmRecords | Select-Object name,ismanaged,modifiedon |
        Export-Csv -Path ".\dv_00_roles_baseline.csv" -NoTypeInformation
    Write-Host "    [EXPORTED] dv_00_roles_baseline.csv ($($allRoles.CrmRecords.Count) roles)" -ForegroundColor Green
} catch {
    Write-Host "    [WARN] Could not export roles" -ForegroundColor Yellow
}

# ── Summary ──
Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor $(if ($issues.Count -eq 0) {"Green"} else {"Yellow"})
if ($issues.Count -eq 0) {
    Write-Host "  VALIDATION PASSED - Ready for Step 02" -ForegroundColor Green
} else {
    Write-Host "  VALIDATION FOUND $($issues.Count) ISSUE(S)" -ForegroundColor Yellow
    foreach ($i in $issues) { Write-Host "    - $i" -ForegroundColor Red }
}
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor $(if ($issues.Count -eq 0) {"Green"} else {"Yellow"})

# Store connection for next script (if running interactively)
$global:CWF_DV_CONN = $conn
Write-Host "  Connection stored in `$global:CWF_DV_CONN for subsequent scripts" -ForegroundColor Gray
Write-Host ""
