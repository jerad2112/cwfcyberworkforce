<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 7: Validate Full Deployment
.DESCRIPTION
    Comprehensive validation: publisher, solution, 21 global choices,
    16 tables with column counts, master data population, and security.
    Generates HTML report + CSV export.
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\07_validate_deployment.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath)

$ErrorActionPreference = "Continue"

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 7: Validate" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url
$prefix = $config.publisher.prefix

$conn = if ($global:CWF_DV_CONN -and $global:CWF_DV_CONN.IsReady) {
    $global:CWF_DV_CONN
} else { Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth }

$baseUrl = "$envUrl/api/data/v9.2"
function Get-H { @{"Authorization"="Bearer $($conn.CurrentAccessToken)";"OData-MaxVersion"="4.0";"OData-Version"="4.0"} }

$results = @()
$pass = 0; $fail = 0; $warn = 0

function Test-It {
    param([string]$Cat,[string]$Test,[string]$Status,[string]$Details="")
    switch($Status){"PASS"{$script:pass++}"FAIL"{$script:fail++}"WARN"{$script:warn++}}
    $c = switch($Status){"PASS"{"Green"}"FAIL"{"Red"}"WARN"{"Yellow"}default{"Gray"}}
    Write-Host "  [$Status] $Test" -ForegroundColor $c
    if ($Details) { Write-Host "         $Details" -ForegroundColor Gray }
    $script:results += [PSCustomObject]@{Category=$Cat;Test=$Test;Status=$Status;Details=$Details;Time=(Get-Date -Format "HH:mm:ss")}
}

# ── Connection ──
Write-Host "  ── Connection ──" -ForegroundColor White
if ($conn.IsReady) { Test-It "Connection" "Dataverse connected" "PASS" $conn.ConnectedOrgFriendlyName }
else { Test-It "Connection" "Dataverse connected" "FAIL"; return }

# ── Publisher ──
Write-Host "`n  ── Publisher ──" -ForegroundColor White
try {
    $pub = Get-CrmRecords -conn $conn -EntityLogicalName publisher `
        -FilterAttribute customizationprefix -FilterOperator eq -FilterValue $prefix `
        -Fields friendlyname,customizationoptionvalueprefix -TopCount 1
    if ($pub.Count -gt 0) {
        Test-It "Publisher" "Publisher exists (prefix: $prefix)" "PASS" "Choice prefix: $($pub.CrmRecords[0].customizationoptionvalueprefix)"
    } else { Test-It "Publisher" "Publisher exists (prefix: $prefix)" "FAIL" }
} catch { Test-It "Publisher" "Publisher check" "FAIL" $_.Exception.Message }

# ── Solution ──
Write-Host "`n  ── Solution ──" -ForegroundColor White
try {
    $sol = Get-CrmRecords -conn $conn -EntityLogicalName solution `
        -FilterAttribute uniquename -FilterOperator eq -FilterValue $config.solution.unique_name `
        -Fields friendlyname,version -TopCount 1
    if ($sol.Count -gt 0) {
        Test-It "Solution" "Solution exists" "PASS" "$($sol.CrmRecords[0].friendlyname) v$($sol.CrmRecords[0].version)"
    } else { Test-It "Solution" "Solution exists" "FAIL" }
} catch { Test-It "Solution" "Solution check" "FAIL" $_.Exception.Message }

# ── Global Choices ──
Write-Host "`n  ── Global Choice Sets ──" -ForegroundColor White
$expectedChoices = @(
    "cwf_workflow_stage","cwf_record_lifecycle","cwf_process_status","cwf_priority",
    "cwf_approval_status","cwf_organization","cwf_sensitivity_category","cwf_sensitivity_sub_label",
    "cwf_compliance_status","cwf_cert_status","cwf_training_category","cwf_training_status",
    "cwf_saar_status","cwf_work_role_category","cwf_rank","cwf_clearance",
    "cwf_severity","cwf_check_status","cwf_access_type","cwf_ato_status","cwf_classification"
)

$choiceCount = 0
foreach ($cn in $expectedChoices) {
    try {
        $c = Invoke-RestMethod -Uri "$baseUrl/GlobalOptionSetDefinitions(Name='$cn')" -Headers (Get-H) -Method Get
        Test-It "Choices" "Choice: $cn" "PASS" "$($c.Options.Count) options"
        $choiceCount++
    } catch {
        Test-It "Choices" "Choice: $cn" "FAIL" "Not found"
    }
}

# ── Tables ──
Write-Host "`n  ── Tables & Columns ──" -ForegroundColor White
$expectedTables = @(
    @{n="cwf_personnel";min=15}, @{n="cwf_work_roles";min=8}, @{n="cwf_work_role_assignments";min=9},
    @{n="cwf_certifications";min=9}, @{n="cwf_personnel_certifications";min=10},
    @{n="cwf_training";min=10}, @{n="cwf_personnel_training";min=10},
    @{n="cwf_saar";min=12}, @{n="cwf_stig_compliance";min=10}, @{n="cwf_poam";min=9},
    @{n="cwf_systems";min=7}, @{n="cwf_waivers";min=9}, @{n="cwf_audit_log";min=7},
    @{n="cwf_notifications";min=7}, @{n="cwf_compliance_reports";min=10},
    @{n="cwf_configuration";min=5}
)

$tableCount = 0
$totalCols = 0
foreach ($tbl in $expectedTables) {
    try {
        $attrs = Invoke-RestMethod `
            -Uri "$baseUrl/EntityDefinitions(LogicalName='$($tbl.n)')/Attributes?`$filter=startswith(LogicalName,'cwf_')&`$select=LogicalName" `
            -Headers (Get-H) -Method Get
        $colCount = $attrs.value.Count
        $totalCols += $colCount
        
        if ($colCount -ge $tbl.min) {
            Test-It "Tables" "Table: $($tbl.n)" "PASS" "$colCount cwf_ columns (min: $($tbl.min))"
        } else {
            Test-It "Tables" "Table: $($tbl.n)" "WARN" "$colCount cwf_ columns (expected min: $($tbl.min))"
        }
        $tableCount++
    } catch {
        Test-It "Tables" "Table: $($tbl.n)" "FAIL" "Not found"
    }
}

# ── Master Data ──
Write-Host "`n  ── Master Data ──" -ForegroundColor White
@(
    @{t="cwf_work_roles";min=15;label="Work Roles"},
    @{t="cwf_certifications";min=10;label="Certifications"},
    @{t="cwf_configuration";min=5;label="Configuration"}
) | ForEach-Object {
    try {
        $records = Get-CrmRecordsByFetch -conn $conn -Fetch @"
<fetch top='500'><entity name='$($_.t)'><attribute name='cwf_name'/></entity></fetch>
"@
        $count = $records.CrmRecords.Count
        if ($count -ge $_.min) {
            Test-It "Data" "Master data: $($_.label)" "PASS" "$count records (min: $($_.min))"
        } else {
            Test-It "Data" "Master data: $($_.label)" "WARN" "$count records (expected: $($_.min)+)"
        }
    } catch { Test-It "Data" "Master data: $($_.label)" "FAIL" $_.Exception.Message }
}

# ── Audit ──
Write-Host "`n  ── Auditing ──" -ForegroundColor White
try {
    $org = Get-CrmRecords -conn $conn -EntityLogicalName organization -Fields isauditenabled -TopCount 1
    $auditOn = $org.CrmRecords[0].isauditenabled
    if ($auditOn) { Test-It "Security" "Auditing enabled" "PASS" }
    else { Test-It "Security" "Auditing enabled" "WARN" "Auditing is OFF - enable in Advanced Settings" }
} catch { Test-It "Security" "Auditing check" "WARN" "Could not verify" }

# ══════════════════════════════════════════════════════════════
# GENERATE HTML REPORT
# ══════════════════════════════════════════════════════════════
$total = $pass + $fail + $warn
$pct = if ($total -gt 0) { [math]::Round(($pass / $total) * 100, 1) } else { 0 }
$ts = Get-Date -Format "yyyyMMdd_HHmmss"

$html = @"
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>CWF Dataverse Validation - $ts</title>
<style>
body{font-family:Arial;max-width:1100px;margin:20px auto;padding:0 20px}
h1{color:#1B2A4A;border-bottom:3px solid #2E75B6;padding-bottom:10px}
.s{display:flex;gap:15px;margin:15px 0}.c{padding:15px;border-radius:8px;flex:1;text-align:center}
.c h3{margin:0;font-size:32px}.c p{margin:5px 0 0;color:#666}
.p{background:#E2EFDA;color:#548235}.f{background:#FCE4EC;color:#C00000}
.w{background:#FFF9C4;color:#BF8F00}.t{background:#D5E8F0;color:#1B2A4A}
table{width:100%;border-collapse:collapse;margin:15px 0}
th{background:#1B2A4A;color:white;padding:8px;text-align:left}
td{padding:6px 8px;border-bottom:1px solid #ddd}tr:nth-child(even){background:#f9f9f9}
.PASS{color:#548235;font-weight:bold}.FAIL{color:#C00000;font-weight:bold}.WARN{color:#BF8F00;font-weight:bold}
</style></head><body>
<h1>CWF Dataverse Deployment Validation</h1>
<p>Environment: $envUrl | Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm") | CUI // FOUO</p>
<div class="s">
<div class="c t"><h3>$total</h3><p>Tests</p></div>
<div class="c p"><h3>$pass</h3><p>Passed</p></div>
<div class="c f"><h3>$fail</h3><p>Failed</p></div>
<div class="c w"><h3>$warn</h3><p>Warnings</p></div>
</div>
<p><strong>Summary:</strong> $tableCount/16 tables, $choiceCount/21 choices, $totalCols total columns, $pct% pass rate</p>
<table><tr><th>Category</th><th>Test</th><th>Status</th><th>Details</th></tr>
$($results | ForEach-Object {"<tr><td>$($_.Category)</td><td>$($_.Test)</td><td class='$($_.Status)'>$($_.Status)</td><td>$($_.Details)</td></tr>"} | Out-String)
</table>
<p style="color:#999;font-size:11px;margin-top:30px">CWF Compliance Portal - Dataverse Deployment Validation | STIG Artifact (NIST CA-8)</p>
</body></html>
"@

$html | Out-File ".\dv_validation_report.html" -Encoding UTF8
$results | Export-Csv ".\dv_validation_results.csv" -NoTypeInformation

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor $(if ($fail -eq 0) {"Green"} else {"Yellow"})
Write-Host "  VALIDATION COMPLETE" -ForegroundColor $(if ($fail -eq 0) {"Green"} else {"Yellow"})
Write-Host "══════════════════════════════════════════════════" -ForegroundColor $(if ($fail -eq 0) {"Green"} else {"Yellow"})
Write-Host "  Passed: $pass | Failed: $fail | Warnings: $warn | Pass rate: $pct%" -ForegroundColor White
Write-Host "  Tables: $tableCount/16 | Choices: $choiceCount/21 | Columns: $totalCols" -ForegroundColor Cyan
Write-Host "  HTML report: dv_validation_report.html" -ForegroundColor Gray
Write-Host "  CSV results: dv_validation_results.csv" -ForegroundColor Gray
Write-Host ""

if ($fail -gt 0) {
    Write-Host "  FAILED TESTS:" -ForegroundColor Red
    $results | Where-Object {$_.Status -eq "FAIL"} | ForEach-Object {
        Write-Host "    $($_.Test): $($_.Details)" -ForegroundColor Red
    }
} else { Write-Host "  ALL TESTS PASSED - Deployment ready" -ForegroundColor Green }
Write-Host ""
