# CWF Dataverse Deployment Pipeline - Complete Setup Guide
# ════════════════════════════════════════════════════════
# Version: 1.0 | Environment: GCC (.crm9.dynamics.com)
# Naming: cwf_[name] lowercase_underscore throughout
# Publisher prefix: cwf | Choice value prefix: 10000
#
# ═══════════════════════════════════════════════════════
# PREREQUISITES - VERIFY BEFORE RUNNING ANY SCRIPT
# ═══════════════════════════════════════════════════════
#
# 1. PnP.PowerShell installed:
#      Install-Module PnP.PowerShell -Scope CurrentUser
#
# 2. Microsoft.Xrm.Tooling installed:
#      Install-Module Microsoft.Xrm.Tooling.CrmConnector.PowerShell -Scope CurrentUser
#
# 3. PAC CLI installed:
#      dotnet tool install --global Microsoft.PowerApps.CLI.Tool
#
# 4. System Administrator role in your Dataverse environment
#    (verified during our walkthrough - you have this)
#
# 5. CAC card inserted and middleware running
#
# ═══════════════════════════════════════════════════════
# HOW TO GET YOUR ENVIRONMENT DETAILS
# ═══════════════════════════════════════════════════════
#
# METHOD 1: Session Details (from the UI)
#   1. Open any D365 app in your environment
#   2. Click the gear icon (top right)
#   3. Click "Session details" or "About"
#   4. Copy: Environment URL, Environment ID, Tenant ID
#
# METHOD 2: make.powerapps.com
#   1. Go to make.powerapps.com
#   2. Select your environment (top right dropdown)
#   3. Click the gear icon > "Session details"
#   4. Or: click "..." on the environment > "Session details"
#
# METHOD 3: PowerShell (after auth)
#   pac auth create --url https://YOUR_ORG.crm9.dynamics.com
#   pac env who
#
# ═══════════════════════════════════════════════════════
# INFORMATION NEEDED (FEED TO ASKSAGE)
# ═══════════════════════════════════════════════════════
#
# Copy this block into AskSage and fill in the values:
#
# ┌──────────────────────────────────────────────────────────┐
# │  DATAVERSE ENVIRONMENT DETAILS                           │
# │                                                          │
# │  1. ENVIRONMENT URL (from Session Details)               │
# │     Format: https://orgXXXXXXXX.crm9.dynamics.com       │
# │     Your value: ____________________________________     │
# │                                                          │
# │  2. ENVIRONMENT ID (GUID from Session Details)           │
# │     Format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx         │
# │     Your value: ____________________________________     │
# │                                                          │
# │  3. TENANT ID (GUID from Session Details)                │
# │     Format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx         │
# │     Your value: ____________________________________     │
# │                                                          │
# │  4. ORGANIZATION UNIQUE NAME (from Session Details)      │
# │     Example: orgcb288a9d                                 │
# │     Your value: ____________________________________     │
# │                                                          │
# │  5. YOUR ADMIN UPN                                       │
# │     Example: john.doe.civ@mail.mil                       │
# │     Your value: ____________________________________     │
# │                                                          │
# │  6. SOLUTION DISPLAY NAME                                │
# │     Default: TACOM G6 CWF Compliance Portal              │
# │     Your value: ____________________________________     │
# │                                                          │
# │  7. PUBLISHER DISPLAY NAME                               │
# │     Default: TACOM G6 CWF                                │
# │     Your value: ____________________________________     │
# │                                                          │
# │  NOTE: The publisher prefix is always "cwf"              │
# │  NOTE: The choice value prefix is always "10000"         │
# │  NOTE: The .crm9 suffix confirms GCC environment         │
# └──────────────────────────────────────────────────────────┘
#
# ═══════════════════════════════════════════════════════
# ASKSAGE PROMPT TO FILL THE CONFIG
# ═══════════════════════════════════════════════════════
#
# Copy and paste this into AskSage:
#
#   "I have a Dataverse deployment config template in JSON format.
#    Please fill in the PLACEHOLDER values with my environment details:
#    - Environment URL: [paste your URL]
#    - Environment ID: [paste your GUID]
#    - Tenant ID: [paste your GUID]
#    - Org unique name: [paste your org name]
#    - Admin UPN: [paste your email]
#    - Solution name: [your solution name]
#    Here is the config template:
#    [paste contents of dv_config.json]"
#
# ═══════════════════════════════════════════════════════
# PIPELINE EXECUTION ORDER
# ═══════════════════════════════════════════════════════
#
# Step 1: Edit dv_config.json (or use AskSage)
# Step 2: .\01_validate_dataverse.ps1 -ConfigPath .\dv_config.json
# Step 3: .\02_create_publisher_solution.ps1 -ConfigPath .\dv_config.json
# Step 4: .\03_create_global_choices.ps1 -ConfigPath .\dv_config.json
# Step 5: .\04_create_tables.ps1 -ConfigPath .\dv_config.json
# Step 6: .\05_add_columns.ps1 -ConfigPath .\dv_config.json
# Step 7: .\06_populate_master_data.ps1 -ConfigPath .\dv_config.json
# Step 8: .\07_validate_deployment.ps1 -ConfigPath .\dv_config.json
#
# NAMING CONVENTION:
# ─────────────────
# Publisher prefix:  cwf
# Table names:       cwf_personnel, cwf_work_roles, cwf_saar
# Column names:      cwf_first_name, cwf_dod_id, cwf_wr_category
# Choice sets:       cwf_workflow_stage, cwf_sensitivity_category
# Choice values:     Start at 10000 (10000, 10001, 10002, ...)
# Solution name:     cwf_compliance_portal
