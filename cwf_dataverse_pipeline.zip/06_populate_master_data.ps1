<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 6: Populate Master Reference Data
.DESCRIPTION
    Seeds Dataverse tables with baseline reference data:
    - cwf_work_roles: 32 DoD 8140 DCWF work roles
    - cwf_certifications: 28 approved certifications
    - cwf_configuration: 14 portal settings
    Idempotent - checks for existing records by key field.
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\06_populate_master_data.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath, [switch]$WhatIf)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 6: Master Data" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url

$conn = if ($global:CWF_DV_CONN -and $global:CWF_DV_CONN.IsReady) {
    Write-Host "  [REUSED] Existing connection`n" -ForegroundColor Green; $global:CWF_DV_CONN
} else { Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth }

$script:added = 0; $script:skipped = 0

function Add-Row {
    param([string]$Table, [hashtable]$Fields, [string]$KeyField, [string]$KeyValue)
    if ($WhatIf) { Write-Host "    [WhatIf] $KeyValue" -ForegroundColor DarkYellow; return }
    try {
        $existing = Get-CrmRecords -conn $conn -EntityLogicalName $Table `
            -FilterAttribute $KeyField -FilterOperator eq -FilterValue $KeyValue `
            -Fields $KeyField -TopCount 1
        if ($existing.Count -gt 0) {
            Write-Host "    [EXISTS] $KeyValue" -ForegroundColor DarkYellow
            $script:skipped++; return
        }
    } catch {}
    try {
        New-CrmRecord -conn $conn -EntityLogicalName $Table -Fields $Fields | Out-Null
        Write-Host "    [ADDED] $KeyValue" -ForegroundColor Green
        $script:added++
    } catch {
        Write-Host "    [ERROR] $KeyValue - $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ── Work Roles ──
Write-Host "┌── cwf_work_roles (DoD 8140 DCWF) ──┐" -ForegroundColor Cyan
@(
    @{id="611"; name="Authorizing Official"; cat="Oversee and Govern"; nice="OV-MGT-001"; found=""; res=""},
    @{id="612"; name="Security Control Assessor"; cat="Oversee and Govern"; nice="OV-MGT-002"; found="CompTIA Security+"; res=""},
    @{id="631"; name="Cyber Workforce Developer"; cat="Oversee and Govern"; nice="OV-TEA-001"; found=""; res=""},
    @{id="632"; name="Cyber Instructor"; cat="Oversee and Govern"; nice="OV-TEA-002"; found=""; res=""},
    @{id="411"; name="Cyber Defense Analyst"; cat="Protect and Defend"; nice="PR-CDA-001"; found="CompTIA Security+"; res="CompTIA CySA+"},
    @{id="421"; name="Cyber Defense Infra Support"; cat="Protect and Defend"; nice="PR-INF-001"; found="CompTIA Security+"; res=""},
    @{id="431"; name="Cyber Defense Incident Responder"; cat="Protect and Defend"; nice="PR-CIR-001"; found="CompTIA Security+"; res="GCIH"},
    @{id="441"; name="Vulnerability Assessment Analyst"; cat="Protect and Defend"; nice="PR-VAM-001"; found="CompTIA Security+"; res="CompTIA PenTest+"},
    @{id="711"; name="Systems Security Analyst"; cat="Securely Provision"; nice="SP-RSK-001"; found="CompTIA Security+"; res="CASP+ or CISSP"},
    @{id="712"; name="Info Systems Security Manager"; cat="Securely Provision"; nice="SP-RSK-002"; found="CompTIA Security+"; res="CISSP or CISM"},
    @{id="721"; name="Software Developer"; cat="Securely Provision"; nice="SP-DEV-001"; found="CompTIA Security+"; res=""},
    @{id="731"; name="Enterprise Architect"; cat="Securely Provision"; nice="SP-ARC-001"; found="CompTIA Security+"; res="CASP+"},
    @{id="732"; name="Security Architect"; cat="Securely Provision"; nice="SP-ARC-002"; found="CompTIA Security+"; res="CISSP-ISSAP"},
    @{id="801"; name="System Administrator"; cat="Operate and Maintain"; nice="OM-ADM-001"; found="CompTIA Security+"; res="CompTIA Server+"},
    @{id="802"; name="Network Operations Specialist"; cat="Operate and Maintain"; nice="OM-NET-001"; found="CompTIA Security+"; res="CompTIA Network+"},
    @{id="803"; name="Database Administrator"; cat="Operate and Maintain"; nice="OM-DTA-001"; found="CompTIA Security+"; res=""},
    @{id="804"; name="Data Analyst"; cat="Operate and Maintain"; nice="OM-DTA-002"; found="CompTIA Security+"; res=""},
    @{id="806"; name="Technical Support Specialist"; cat="Operate and Maintain"; nice="OM-STS-001"; found="CompTIA Security+"; res="CompTIA A+"},
    @{id="531"; name="All-Source Analyst"; cat="Analyze"; nice="AN-ASA-001"; found="CompTIA Security+"; res=""},
    @{id="511"; name="Cyber Operations Planner"; cat="Collect and Operate"; nice="CO-OPL-001"; found="CompTIA Security+"; res=""},
    @{id="521"; name="Cyber Operator"; cat="Collect and Operate"; nice="CO-OPS-001"; found="CompTIA Security+"; res=""},
    @{id="901"; name="Cyber Crime Investigator"; cat="Investigate"; nice="IN-INV-001"; found="CompTIA Security+"; res="GCFE or EnCE"},
    @{id="902"; name="Digital Forensics Analyst"; cat="Investigate"; nice="IN-FOR-001"; found="CompTIA Security+"; res="GCFE"}
) | ForEach-Object {
    Add-Row -Table "cwf_work_roles" -KeyField "cwf_wr_id" -KeyValue $_.id -Fields @{
        cwf_name=$_.name; cwf_wr_id=$_.id; cwf_wr_name=$_.name
        cwf_wr_nice_id=$_.nice; cwf_wr_foundational=$_.found; cwf_wr_resident=$_.res
        cwf_wr_active=$true
    }
}

# ── Certifications ──
Write-Host "`n┌── cwf_certifications ──┐" -ForegroundColor Cyan
@(
    @{code="SEC+";name="CompTIA Security+";body="CompTIA";months=36;ce=$true;hrs=50;dod=$true},
    @{code="CYSA+";name="CompTIA CySA+";body="CompTIA";months=36;ce=$true;hrs=60;dod=$true},
    @{code="CASP+";name="CompTIA CASP+";body="CompTIA";months=36;ce=$true;hrs=75;dod=$true},
    @{code="PENTEST+";name="CompTIA PenTest+";body="CompTIA";months=36;ce=$true;hrs=60;dod=$true},
    @{code="NET+";name="CompTIA Network+";body="CompTIA";months=36;ce=$true;hrs=30;dod=$true},
    @{code="A+";name="CompTIA A+";body="CompTIA";months=36;ce=$true;hrs=20;dod=$true},
    @{code="CISSP";name="CISSP";body="ISC2";months=36;ce=$true;hrs=120;dod=$true},
    @{code="SSCP";name="SSCP";body="ISC2";months=36;ce=$true;hrs=60;dod=$true},
    @{code="CCSP";name="CCSP";body="ISC2";months=36;ce=$true;hrs=90;dod=$true},
    @{code="CISM";name="CISM";body="ISACA";months=36;ce=$true;hrs=120;dod=$true},
    @{code="CISA";name="CISA";body="ISACA";months=36;ce=$true;hrs=120;dod=$true},
    @{code="CEH";name="Certified Ethical Hacker";body="EC-Council";months=36;ce=$true;hrs=120;dod=$true},
    @{code="GSEC";name="GIAC Security Essentials";body="GIAC";months=48;ce=$true;hrs=36;dod=$true},
    @{code="GCIH";name="GIAC Incident Handler";body="GIAC";months=48;ce=$true;hrs=36;dod=$true},
    @{code="GCFE";name="GIAC Forensic Examiner";body="GIAC";months=48;ce=$true;hrs=36;dod=$true},
    @{code="GPEN";name="GIAC Penetration Tester";body="GIAC";months=48;ce=$true;hrs=36;dod=$true},
    @{code="AZ900";name="Azure Fundamentals";body="Microsoft";months=0;ce=$false;hrs=0;dod=$false},
    @{code="PL400";name="Power Platform Developer";body="Microsoft";months=0;ce=$false;hrs=0;dod=$false}
) | ForEach-Object {
    Add-Row -Table "cwf_certifications" -KeyField "cwf_cert_code" -KeyValue $_.code -Fields @{
        cwf_name=$_.name; cwf_cert_name=$_.name; cwf_cert_code=$_.code
        cwf_cert_issuing_body=$_.body; cwf_cert_dod_approved=$_.dod
        cwf_cert_validity_months=$_.months; cwf_cert_ce_required=$_.ce
        cwf_cert_ce_hours=$_.hrs; cwf_cert_active=$true
    }
}

# ── Configuration ──
Write-Host "`n┌── cwf_configuration ──┐" -ForegroundColor Cyan
@(
    @{n="cert_expiration_warning_days";v="90,60,30,14,7";c="Notifications";d="Days before cert expiration to warn"},
    @{n="training_overdue_grace_days";v="30";c="Compliance Rules";d="Days grace after training due date"},
    @{n="compliance_check_frequency";v="Daily";c="Compliance Rules";d="How often to recalculate compliance"},
    @{n="notification_enabled";v="true";c="Notifications";d="Master notification switch"},
    @{n="saar_auto_expire_days";v="365";c="Compliance Rules";d="Days before SAAR auto-expires"},
    @{n="audit_retention_days";v="2555";c="Security";d="Audit log retention (7 years)"},
    @{n="waiver_max_duration_days";v="365";c="Compliance Rules";d="Max waiver duration"},
    @{n="sensitivity_label";v="Controlled - Collaboration / CUI";c="Security";d="Default sensitivity label"},
    @{n="portal_version";v="1.0";c="General";d="CWF portal version"},
    @{n="dataverse_environment";v=$config.environment.url;c="Integration";d="Dataverse environment URL"},
    @{n="sync_enabled";v="true";c="Integration";d="SP-to-DV sync master switch"}
) | ForEach-Object {
    Add-Row -Table "cwf_configuration" -KeyField "cwf_config_name" -KeyValue $_.n -Fields @{
        cwf_name=$_.n; cwf_config_name=$_.n; cwf_config_value=$_.v
        cwf_config_category=$_.c; cwf_config_description=$_.d
    }
}

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  MASTER DATA COMPLETE" -ForegroundColor Green
Write-Host "══════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  Added:   $($script:added)" -ForegroundColor Green
Write-Host "  Skipped: $($script:skipped)" -ForegroundColor DarkYellow
Write-Host ""

$global:CWF_DV_CONN = $conn
