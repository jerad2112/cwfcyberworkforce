<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 2: Create Publisher & Solution
.DESCRIPTION
    Creates the CWF publisher (prefix: cwf, choice value prefix: 10000)
    and the CWF Compliance Portal solution in Dataverse.
    Idempotent - skips if already exist.
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\02_create_publisher_solution.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath, [switch]$WhatIf)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 2: Publisher & Solution" -ForegroundColor Cyan
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url

# ── Connect ──
Write-Host "  Connecting to: $envUrl" -ForegroundColor Gray
$conn = if ($global:CWF_DV_CONN -and $global:CWF_DV_CONN.IsReady) {
    Write-Host "  [REUSED] Existing connection" -ForegroundColor Green
    $global:CWF_DV_CONN
} else {
    Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth
}

if (-not $conn.IsReady) { Write-Host "  [FAIL] Not connected" -ForegroundColor Red; return }

# ── Create Publisher ──
Write-Host "`n  Creating publisher..." -ForegroundColor White
$prefix = $config.publisher.prefix
$pubName = $config.publisher.unique_name

$existingPub = Get-CrmRecords -conn $conn -EntityLogicalName publisher `
    -FilterAttribute customizationprefix -FilterOperator eq -FilterValue $prefix `
    -Fields friendlyname -TopCount 1

if ($existingPub.Count -gt 0) {
    Write-Host "    [EXISTS] Publisher already exists: $($existingPub.CrmRecords[0].friendlyname)" -ForegroundColor DarkYellow
    $publisherId = $existingPub.CrmRecords[0].publisherid
} else {
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create publisher: $($config.publisher.display_name)" -ForegroundColor DarkYellow
    } else {
        $pubRecord = @{
            friendlyname                    = $config.publisher.display_name
            uniquename                      = $pubName
            customizationprefix             = $prefix
            customizationoptionvalueprefix  = $config.publisher.choice_value_prefix
            description                     = $config.publisher.description
        }
        $publisherId = New-CrmRecord -conn $conn -EntityLogicalName publisher -Fields $pubRecord
        Write-Host "    [CREATED] $($config.publisher.display_name)" -ForegroundColor Green
        Write-Host "    Prefix: $prefix | Choice prefix: $($config.publisher.choice_value_prefix)" -ForegroundColor Gray
        Write-Host "    Publisher ID: $publisherId" -ForegroundColor Gray
    }
}

# ── Create Solution ──
Write-Host "`n  Creating solution..." -ForegroundColor White
$solName = $config.solution.unique_name

$existingSol = Get-CrmRecords -conn $conn -EntityLogicalName solution `
    -FilterAttribute uniquename -FilterOperator eq -FilterValue $solName `
    -Fields friendlyname -TopCount 1

if ($existingSol.Count -gt 0) {
    Write-Host "    [EXISTS] Solution already exists: $($existingSol.CrmRecords[0].friendlyname)" -ForegroundColor DarkYellow
} else {
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create solution: $($config.solution.display_name)" -ForegroundColor DarkYellow
    } else {
        # Get publisher ID if we don't have it
        if (-not $publisherId) {
            $pubLookup = Get-CrmRecords -conn $conn -EntityLogicalName publisher `
                -FilterAttribute customizationprefix -FilterOperator eq -FilterValue $prefix `
                -Fields publisherid -TopCount 1
            $publisherId = $pubLookup.CrmRecords[0].publisherid
        }
        
        $solRecord = @{
            friendlyname                        = $config.solution.display_name
            uniquename                          = $solName
            version                             = $config.solution.version
            description                         = $config.solution.description
            "publisherid@odata.bind"            = "/publishers($publisherId)"
        }
        
        $solutionId = New-CrmRecord -conn $conn -EntityLogicalName solution -Fields $solRecord
        Write-Host "    [CREATED] $($config.solution.display_name) v$($config.solution.version)" -ForegroundColor Green
        Write-Host "    Solution ID: $solutionId" -ForegroundColor Gray
    }
}

# ── Export evidence ──
Write-Host "`n  Exporting evidence..." -ForegroundColor White
@([PSCustomObject]@{
    publisher_name=$config.publisher.display_name; prefix=$prefix
    choice_prefix=$config.publisher.choice_value_prefix
    solution_name=$config.solution.display_name; solution_unique=$solName
    version=$config.solution.version; status="Created"
}) | Export-Csv -Path ".\dv_02_publisher_solution.csv" -NoTypeInformation
Write-Host "    [EXPORTED] dv_02_publisher_solution.csv" -ForegroundColor Green

$global:CWF_DV_CONN = $conn
Write-Host "`n  [DONE] Ready for Step 03`n" -ForegroundColor Green
