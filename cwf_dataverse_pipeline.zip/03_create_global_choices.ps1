<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 3: Create Global Choice Sets
.DESCRIPTION
    Creates all global choice sets (OptionSets) for the CWF solution.
    Uses Dataverse Web API for full control over naming and values.
    
    All names use lowercase_underscore: cwf_workflow_stage, cwf_priority, etc.
    All values start at 10000 (matching publisher choice_value_prefix).
    
    CHOICE SETS CREATED (21 total):
    ───────────────────────────────
    Shared (reusable across solutions):
      cwf_workflow_stage, cwf_record_lifecycle, cwf_process_status,
      cwf_priority, cwf_approval_status, cwf_organization,
      cwf_sensitivity_category, cwf_sensitivity_sub_label
    
    CWF-Specific:
      cwf_compliance_status, cwf_cert_status, cwf_training_category,
      cwf_training_status, cwf_saar_status, cwf_work_role_category,
      cwf_rank, cwf_clearance, cwf_severity, cwf_check_status,
      cwf_access_type, cwf_ato_status, cwf_classification
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\03_create_global_choices.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath, [switch]$WhatIf)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 3: Global Choices" -ForegroundColor Cyan
Write-Host "  Naming: cwf_[name] lowercase_underscore" -ForegroundColor Gray
Write-Host "  Values: Starting at 10000" -ForegroundColor Gray
Write-Host "══════════════════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url

# ── Connect ──
$conn = if ($global:CWF_DV_CONN -and $global:CWF_DV_CONN.IsReady) {
    Write-Host "  [REUSED] Existing connection" -ForegroundColor Green
    $global:CWF_DV_CONN
} else {
    Write-Host "  Connecting to: $envUrl" -ForegroundColor Gray
    Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth
}

$baseUrl = "$envUrl/api/data/v9.2"

function Get-AuthHeaders {
    return @{
        "Authorization"    = "Bearer $($conn.CurrentAccessToken)"
        "Content-Type"     = "application/json"
        "OData-MaxVersion" = "4.0"
        "OData-Version"    = "4.0"
    }
}

# ══════════════════════════════════════════════════════════════
# HELPER: Create a global option set
# ══════════════════════════════════════════════════════════════
function New-GlobalChoice {
    param(
        [string]$Name,
        [string]$DisplayName,
        [string]$Description,
        [string[]]$Labels
    )
    
    Write-Host "`n  ── $Name ──" -ForegroundColor White
    
    # Check if exists
    try {
        $check = Invoke-RestMethod -Uri "$baseUrl/GlobalOptionSetDefinitions(Name='$Name')" `
            -Headers (Get-AuthHeaders) -Method Get -ErrorAction Stop
        Write-Host "    [EXISTS] $($check.Name) ($($check.Options.Count) options)" -ForegroundColor DarkYellow
        return
    } catch {
        # 404 = doesn't exist, which is what we want
        if ($_.Exception.Response.StatusCode -ne 404 -and $_.Exception.Message -notmatch "404") {
            # Only ignore 404, re-check for other errors
        }
    }
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create: $DisplayName ($($Labels.Count) options)" -ForegroundColor DarkYellow
        return
    }
    
    # Build options array starting at 10000
    $options = @()
    for ($i = 0; $i -lt $Labels.Count; $i++) {
        $options += @{
            Value = 10000 + $i
            Label = @{
                LocalizedLabels = @(@{
                    Label = $Labels[$i]
                    LanguageCode = 1033
                })
            }
        }
    }
    
    $body = @{
        "@odata.type"  = "Microsoft.Dynamics.CRM.OptionSetMetadata"
        Name           = $Name
        DisplayName    = @{
            LocalizedLabels = @(@{ Label = $DisplayName; LanguageCode = 1033 })
        }
        Description    = @{
            LocalizedLabels = @(@{ Label = $Description; LanguageCode = 1033 })
        }
        IsGlobal       = $true
        OptionSetType  = "Picklist"
        Options        = $options
    } | ConvertTo-Json -Depth 10
    
    try {
        Invoke-RestMethod -Uri "$baseUrl/GlobalOptionSetDefinitions" `
            -Headers (Get-AuthHeaders) -Method Post -Body $body | Out-Null
        Write-Host "    [CREATED] $DisplayName ($($Labels.Count) options: $($Labels[0])...$($Labels[-1]))" -ForegroundColor Green
    } catch {
        $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $msg = if ($err) { $err.error.message } else { $_.Exception.Message }
        if ($msg -match "already exists") {
            Write-Host "    [EXISTS] $Name" -ForegroundColor DarkYellow
        } else {
            Write-Host "    [ERROR] $Name - $msg" -ForegroundColor Red
        }
    }
}

$inventory = @()

# ══════════════════════════════════════════════════════════════
# SHARED CHOICE SETS (reusable across solutions)
# ══════════════════════════════════════════════════════════════
Write-Host "┌─────────────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  Shared Choice Sets                             │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────────────┘" -ForegroundColor Cyan

New-GlobalChoice -Name "cwf_workflow_stage" -DisplayName "Workflow Stage" `
    -Description "Position in a multi-step business process" `
    -Labels @("Draft","In Progress","Pending Review","Approved","Archived")
$inventory += @{name="cwf_workflow_stage"; count=5; type="Shared"}

New-GlobalChoice -Name "cwf_record_lifecycle" -DisplayName "Record Lifecycle" `
    -Description "Broad lifecycle phase of a record" `
    -Labels @("New","Active","Pending","Suspended","Archived","Retired")
$inventory += @{name="cwf_record_lifecycle"; count=6; type="Shared"}

New-GlobalChoice -Name "cwf_process_status" -DisplayName "Process Status" `
    -Description "Completion state of a task or action item" `
    -Labels @("Not Started","In Progress","Pending Approval","Completed","Cancelled")
$inventory += @{name="cwf_process_status"; count=5; type="Shared"}

New-GlobalChoice -Name "cwf_priority" -DisplayName "Priority" `
    -Description "Urgency classification" `
    -Labels @("Critical","High","Medium","Low")
$inventory += @{name="cwf_priority"; count=4; type="Shared"}

New-GlobalChoice -Name "cwf_approval_status" -DisplayName "Approval Status" `
    -Description "Approval decision state" `
    -Labels @("Draft","Submitted","Approved","Rejected","Returned")
$inventory += @{name="cwf_approval_status"; count=5; type="Shared"}

New-GlobalChoice -Name "cwf_organization" -DisplayName "Organization" `
    -Description "Organizational unit identifier" `
    -Labels @("TACOM G-1","TACOM G-2","TACOM G-3","TACOM G-4","TACOM G-6","TACOM G-8")
$inventory += @{name="cwf_organization"; count=6; type="Shared"}

New-GlobalChoice -Name "cwf_sensitivity_category" -DisplayName "Sensitivity Category" `
    -Description "MIP top-level sensitivity label category" `
    -Labels @("Uncontrolled","Controlled - Collaboration")
$inventory += @{name="cwf_sensitivity_category"; count=2; type="Shared"}

New-GlobalChoice -Name "cwf_sensitivity_sub_label" -DisplayName "Sensitivity Label" `
    -Description "MIP sub-label within selected category" `
    -Labels @("General","Secured (Any)","Secured (Internal Only)","Recipients Only","CUI","CUI - Secured (Internal Only)","CUI - Recipients Only","CUI - DoD Community Only")
$inventory += @{name="cwf_sensitivity_sub_label"; count=8; type="Shared"}

# ══════════════════════════════════════════════════════════════
# CWF-SPECIFIC CHOICE SETS
# ══════════════════════════════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  CWF-Specific Choice Sets                       │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────────────┘" -ForegroundColor Cyan

New-GlobalChoice -Name "cwf_compliance_status" -DisplayName "Compliance Status" `
    -Description "CWF compliance state" `
    -Labels @("Compliant","Non-Compliant","Partially Compliant","Exempt","Pending Review")
$inventory += @{name="cwf_compliance_status"; count=5; type="CWF"}

New-GlobalChoice -Name "cwf_cert_status" -DisplayName "Certification Status" `
    -Description "Status of a held certification" `
    -Labels @("Active","Expired","Pending","Revoked","Suspended")
$inventory += @{name="cwf_cert_status"; count=5; type="CWF"}

New-GlobalChoice -Name "cwf_training_category" -DisplayName "Training Category" `
    -Description "DoD 8140 training category" `
    -Labels @("Foundational","Resident","Core","Elective","Continuous Learning")
$inventory += @{name="cwf_training_category"; count=5; type="CWF"}

New-GlobalChoice -Name "cwf_training_status" -DisplayName "Training Status" `
    -Description "Training completion state" `
    -Labels @("Not Started","In Progress","Completed","Expired","Waived")
$inventory += @{name="cwf_training_status"; count=5; type="CWF"}

New-GlobalChoice -Name "cwf_saar_status" -DisplayName "SAAR Workflow Status" `
    -Description "DD 2875 SAAR approval workflow state" `
    -Labels @("Draft","Submitted","Supervisor Approved","IA Approved","Rejected","Returned","Revoked")
$inventory += @{name="cwf_saar_status"; count=7; type="CWF"}

New-GlobalChoice -Name "cwf_work_role_category" -DisplayName "Work Role Category" `
    -Description "DCWF work role category" `
    -Labels @("Securely Provision","Operate and Maintain","Oversee and Govern","Protect and Defend","Analyze","Collect and Operate","Investigate")
$inventory += @{name="cwf_work_role_category"; count=7; type="CWF"}

New-GlobalChoice -Name "cwf_rank" -DisplayName "Rank/Grade" `
    -Description "Military rank or civilian grade" `
    -Labels @("E1","E2","E3","E4","E5","E6","E7","E8","E9","W1","W2","W3","W4","W5","O1","O2","O3","O4","O5","O6","O7","O8","O9","O10","GS-05","GS-07","GS-09","GS-11","GS-12","GS-13","GS-14","GS-15","SES","CTR")
$inventory += @{name="cwf_rank"; count=34; type="CWF"}

New-GlobalChoice -Name "cwf_clearance" -DisplayName "Clearance Level" `
    -Description "Security clearance level" `
    -Labels @("None","Confidential","Secret","Top Secret","TS/SCI")
$inventory += @{name="cwf_clearance"; count=5; type="CWF"}

New-GlobalChoice -Name "cwf_severity" -DisplayName "STIG Severity" `
    -Description "STIG finding severity category" `
    -Labels @("CAT I","CAT II","CAT III")
$inventory += @{name="cwf_severity"; count=3; type="CWF"}

New-GlobalChoice -Name "cwf_check_status" -DisplayName "STIG Check Status" `
    -Description "STIG checklist item status" `
    -Labels @("Not Reviewed","Not Applicable","Open","Not a Finding")
$inventory += @{name="cwf_check_status"; count=4; type="CWF"}

New-GlobalChoice -Name "cwf_access_type" -DisplayName "Access Type" `
    -Description "SAAR access request type" `
    -Labels @("New Access","Modify","Remove","Renewal")
$inventory += @{name="cwf_access_type"; count=4; type="CWF"}

New-GlobalChoice -Name "cwf_ato_status" -DisplayName "ATO Status" `
    -Description "System authorization status" `
    -Labels @("Active ATO","Conditional ATO","IATT","Denied","Pending","Expired")
$inventory += @{name="cwf_ato_status"; count=6; type="CWF"}

New-GlobalChoice -Name "cwf_classification" -DisplayName "Classification" `
    -Description "System classification level" `
    -Labels @("Unclassified","CUI","Secret","Top Secret")
$inventory += @{name="cwf_classification"; count=4; type="CWF"}

# ══════════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════════
$totalOptions = ($inventory | Measure-Object -Property count -Sum).Sum
$sharedCount = ($inventory | Where-Object { $_.type -eq "Shared" }).Count
$cwfCount = ($inventory | Where-Object { $_.type -eq "CWF" }).Count

Write-Host "`n══════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  GLOBAL CHOICE SETS COMPLETE" -ForegroundColor Green
Write-Host "══════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  Shared choices:     $sharedCount" -ForegroundColor White
Write-Host "  CWF-specific:       $cwfCount" -ForegroundColor White
Write-Host "  Total choice sets:  $($inventory.Count)" -ForegroundColor Cyan
Write-Host "  Total options:      $totalOptions" -ForegroundColor Cyan
Write-Host "  All values start at 10000" -ForegroundColor Green
Write-Host ""

$inventory | ForEach-Object { [PSCustomObject]$_ } | 
    Export-Csv -Path ".\dv_03_global_choices.csv" -NoTypeInformation
Write-Host "  Inventory: dv_03_global_choices.csv" -ForegroundColor Gray

Write-Host "`n  IMPORTANT: Add these choice sets to your solution:" -ForegroundColor Yellow
Write-Host "  make.powerapps.com > Solutions > $($config.solution.display_name)" -ForegroundColor White
Write-Host "  > Add existing > Choice > select all cwf_* choices" -ForegroundColor White
Write-Host ""

$global:CWF_DV_CONN = $conn
