<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 5: Add Columns to All Tables
.DESCRIPTION
    Adds all custom columns to the 16 CWF tables created in Step 4.
    Supports: String, Memo, Integer, DateTime, Boolean, Picklist (global choice),
    Lookup, and Money column types.
    
    All column names use lowercase_underscore with cwf_ prefix.
    Choice columns reference global choice sets created in Step 3.
    
    TOTAL: 16 tables, ~170 columns
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\05_add_columns.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath, [switch]$WhatIf)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 5: Add Columns" -ForegroundColor Cyan
Write-Host "  Naming: cwf_[name] lowercase_underscore" -ForegroundColor Gray
Write-Host "══════════════════════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url

$conn = if ($global:CWF_DV_CONN -and $global:CWF_DV_CONN.IsReady) {
    Write-Host "  [REUSED] Existing connection`n" -ForegroundColor Green
    $global:CWF_DV_CONN
} else {
    Write-Host "  Connecting to: $envUrl" -ForegroundColor Gray
    Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth
}

$baseUrl = "$envUrl/api/data/v9.2"
$script:colCount = 0
$script:errCount = 0

function Get-AuthHeaders {
    return @{
        "Authorization"    = "Bearer $($conn.CurrentAccessToken)"
        "Content-Type"     = "application/json"
        "OData-MaxVersion" = "4.0"
        "OData-Version"    = "4.0"
    }
}

# ══════════════════════════════════════════════════════════════
# COLUMN CREATION HELPER
# ══════════════════════════════════════════════════════════════
function Add-DVColumn {
    param(
        [string]$Table,          # e.g., "cwf_personnel"
        [string]$SchemaName,     # e.g., "cwf_first_name"
        [string]$DisplayName,    # e.g., "First Name"
        [string]$Type,           # String, Memo, DateTime, Boolean, Integer, Decimal, Choice, Lookup
        [bool]$Required = $false,
        [string]$GlobalChoice = "",  # Name of global option set for Choice type
        [int]$MaxLength = 200,
        [string]$Description = ""
    )
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] $SchemaName ($Type)" -ForegroundColor DarkYellow
        $script:colCount++
        return
    }
    
    $label = @{
        "@odata.type"    = "Microsoft.Dynamics.CRM.Label"
        LocalizedLabels  = @(@{
            "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
            Label         = $DisplayName
            LanguageCode  = 1033
        })
    }
    
    $reqLevel = @{
        Value        = if ($Required) { "ApplicationRequired" } else { "None" }
        CanBeChanged = $true
    }
    
    $body = $null
    
    switch ($Type) {
        "String" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "String"
                AttributeTypeName = @{ Value = "StringType" }
                MaxLength         = $MaxLength
                FormatName        = @{ Value = "Text" }
            }
        }
        "Memo" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.MemoAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "Memo"
                AttributeTypeName = @{ Value = "MemoType" }
                MaxLength         = 10000
                Format            = "TextArea"
            }
        }
        "DateTime" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.DateTimeAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "DateTime"
                AttributeTypeName = @{ Value = "DateTimeType" }
                Format            = "DateOnly"
            }
        }
        "Boolean" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.BooleanAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "Boolean"
                AttributeTypeName = @{ Value = "BooleanType" }
                OptionSet         = @{
                    TrueOption    = @{ Value = 1; Label = @{ LocalizedLabels = @(@{ Label="Yes"; LanguageCode=1033 }) } }
                    FalseOption   = @{ Value = 0; Label = @{ LocalizedLabels = @(@{ Label="No";  LanguageCode=1033 }) } }
                }
            }
        }
        "Integer" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.IntegerAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "Integer"
                AttributeTypeName = @{ Value = "IntegerType" }
                MinValue          = 0
                MaxValue          = 2147483647
            }
        }
        "Decimal" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.DecimalAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "Decimal"
                AttributeTypeName = @{ Value = "DecimalType" }
                Precision         = 2
                MinValue          = 0
                MaxValue          = 100000000
            }
        }
        "Choice" {
            $body = @{
                "@odata.type"       = "Microsoft.Dynamics.CRM.PicklistAttributeMetadata"
                SchemaName          = $SchemaName
                DisplayName         = $label
                RequiredLevel       = $reqLevel
                AttributeType       = "Picklist"
                AttributeTypeName   = @{ Value = "PicklistType" }
                "GlobalOptionSet@odata.bind" = "/GlobalOptionSetDefinitions(Name='$GlobalChoice')"
            }
        }
        "Url" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "String"
                AttributeTypeName = @{ Value = "StringType" }
                MaxLength         = 500
                FormatName        = @{ Value = "Url" }
            }
        }
        "Email" {
            $body = @{
                "@odata.type"     = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
                SchemaName        = $SchemaName
                DisplayName       = $label
                RequiredLevel     = $reqLevel
                AttributeType     = "String"
                AttributeTypeName = @{ Value = "StringType" }
                MaxLength         = 320
                FormatName        = @{ Value = "Email" }
            }
        }
    }
    
    if (-not $body) {
        Write-Host "    [SKIP] $SchemaName - unsupported type: $Type" -ForegroundColor Yellow
        return
    }
    
    $jsonBody = $body | ConvertTo-Json -Depth 10
    $uri = "$baseUrl/EntityDefinitions(LogicalName='$Table')/Attributes"
    
    try {
        Invoke-RestMethod -Uri $uri -Headers (Get-AuthHeaders) -Method Post -Body $jsonBody | Out-Null
        Write-Host "    [ADDED] $SchemaName ($Type)" -ForegroundColor Green
        $script:colCount++
    } catch {
        $errMsg = $_.ErrorDetails.Message
        if ($errMsg -match "already exists") {
            Write-Host "    [EXISTS] $SchemaName" -ForegroundColor DarkYellow
            $script:colCount++
        } else {
            $err = try { ($errMsg | ConvertFrom-Json).error.message } catch { $_.Exception.Message }
            Write-Host "    [ERROR] $SchemaName - $err" -ForegroundColor Red
            $script:errCount++
        }
    }
}

# Shorthand
function C { param($tbl,$sn,$dn,$ty,$req=$false,$gc="",$ml=200)
    Add-DVColumn -Table $tbl -SchemaName $sn -DisplayName $dn -Type $ty -Required $req -GlobalChoice $gc -MaxLength $ml
}

# ══════════════════════════════════════════════════════════════
# TABLE 1: cwf_personnel
# ══════════════════════════════════════════════════════════════
$t = "cwf_personnel"
Write-Host "┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_first_name"        "First Name"         "String"   $true
C $t "cwf_last_name"         "Last Name"          "String"   $true
C $t "cwf_dod_id"            "DoD ID"             "String"   $true
C $t "cwf_email"             "Email"              "Email"    $true
C $t "cwf_phone"             "Phone"              "String"
C $t "cwf_rank"              "Rank/Grade"         "Choice"   $true  "cwf_rank"
C $t "cwf_organization"      "Organization"       "Choice"   $true  "cwf_organization"
C $t "cwf_duty_position"     "Duty Position"      "String"
C $t "cwf_supervisor_email"  "Supervisor Email"   "Email"
C $t "cwf_clearance"         "Clearance Level"    "Choice"   $false "cwf_clearance"
C $t "cwf_compliance_status" "Compliance Status"  "Choice"   $false "cwf_compliance_status"
C $t "cwf_personnel_status"  "Personnel Status"   "Choice"   $true  "cwf_record_lifecycle"
C $t "cwf_onboard_date"      "Onboard Date"       "DateTime"
C $t "cwf_separation_date"   "Separation Date"    "DateTime"
C $t "cwf_sensitivity_cat"   "Sensitivity"        "Choice"   $false "cwf_sensitivity_category"
C $t "cwf_sensitivity_label" "Sensitivity Label"  "Choice"   $false "cwf_sensitivity_sub_label"
C $t "cwf_notes"             "Notes"              "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 2: cwf_work_roles
# ══════════════════════════════════════════════════════════════
$t = "cwf_work_roles"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_wr_id"             "Work Role ID"              "String"   $true
C $t "cwf_wr_name"           "Work Role Name"            "String"   $true
C $t "cwf_wr_category"       "Work Role Category"        "Choice"   $true  "cwf_work_role_category"
C $t "cwf_wr_nice_id"        "NICE Framework ID"         "String"
C $t "cwf_wr_description"    "Description"               "Memo"
C $t "cwf_wr_required_certs" "Required Certifications"   "Memo"
C $t "cwf_wr_foundational"   "Foundational Qual"         "String"
C $t "cwf_wr_resident"       "Resident Course"           "String"
C $t "cwf_wr_active"         "Active"                    "Boolean"

# ══════════════════════════════════════════════════════════════
# TABLE 3: cwf_work_role_assignments
# ══════════════════════════════════════════════════════════════
$t = "cwf_work_role_assignments"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_wra_personnel_name" "Personnel Name"         "String"   $true
C $t "cwf_wra_dod_id"         "Personnel DoD ID"       "String"   $true
C $t "cwf_wra_work_role"      "Work Role"              "String"   $true
C $t "cwf_wra_work_role_id"   "Work Role ID"           "String"
C $t "cwf_wra_primary"        "Primary Role"           "Boolean"
C $t "cwf_wra_assign_date"    "Assignment Date"        "DateTime" $true
C $t "cwf_wra_qual_status"    "Qualification Status"   "Choice"   $false "cwf_compliance_status"
C $t "cwf_wra_qual_date"      "Qualification Date"     "DateTime"
C $t "cwf_wra_exp_date"       "Expiration Date"        "DateTime"
C $t "cwf_wra_notes"          "Notes"                  "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 4: cwf_certifications
# ══════════════════════════════════════════════════════════════
$t = "cwf_certifications"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_cert_name"            "Certification Name"     "String"   $true
C $t "cwf_cert_code"            "Certification Code"     "String"   $true
C $t "cwf_cert_issuing_body"    "Issuing Body"           "String"   $true
C $t "cwf_cert_dod_approved"    "DoD 8140 Approved"      "Boolean"
C $t "cwf_cert_validity_months" "Validity (Months)"      "Integer"
C $t "cwf_cert_ce_required"     "CE Required"            "Boolean"
C $t "cwf_cert_ce_hours"        "CE Hours Required"      "Integer"
C $t "cwf_cert_mapped_wr"       "Mapped Work Roles"      "Memo"
C $t "cwf_cert_description"     "Description"            "Memo"
C $t "cwf_cert_active"          "Active"                 "Boolean"

# ══════════════════════════════════════════════════════════════
# TABLE 5: cwf_personnel_certifications
# ══════════════════════════════════════════════════════════════
$t = "cwf_personnel_certifications"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_pc_personnel_name" "Personnel Name"       "String"   $true
C $t "cwf_pc_dod_id"         "Personnel DoD ID"     "String"   $true
C $t "cwf_pc_cert_name"      "Certification"        "String"   $true
C $t "cwf_pc_cert_code"      "Certification Code"   "String"
C $t "cwf_pc_date_earned"    "Date Earned"          "DateTime" $true
C $t "cwf_pc_exp_date"       "Expiration Date"      "DateTime"
C $t "cwf_pc_cert_status"    "Cert Status"          "Choice"   $true  "cwf_cert_status"
C $t "cwf_pc_cert_number"    "Certificate Number"   "String"
C $t "cwf_pc_verify_url"     "Verification URL"     "Url"
C $t "cwf_pc_ce_completed"   "CE Hours Completed"   "Integer"
C $t "cwf_pc_notes"          "Notes"                "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 6: cwf_training
# ══════════════════════════════════════════════════════════════
$t = "cwf_training"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_tr_course_name"   "Course Name"         "String"   $true
C $t "cwf_tr_course_code"   "Course Code"         "String"
C $t "cwf_tr_category"      "Training Category"   "Choice"   $true  "cwf_training_category"
C $t "cwf_tr_provider"      "Provider"            "String"
C $t "cwf_tr_duration"      "Duration (Hours)"    "Integer"
C $t "cwf_tr_delivery"      "Delivery Method"     "String"
C $t "cwf_tr_mapped_wr"     "Mapped Work Roles"   "Memo"
C $t "cwf_tr_dod_approved"  "DoD 8140 Approved"   "Boolean"
C $t "cwf_tr_url"           "URL"                 "Url"
C $t "cwf_tr_description"   "Description"         "Memo"
C $t "cwf_tr_active"        "Active"              "Boolean"

# ══════════════════════════════════════════════════════════════
# TABLE 7: cwf_personnel_training
# ══════════════════════════════════════════════════════════════
$t = "cwf_personnel_training"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_pt_personnel_name" "Personnel Name"     "String"   $true
C $t "cwf_pt_dod_id"         "Personnel DoD ID"   "String"   $true
C $t "cwf_pt_course_name"    "Course Name"        "String"   $true
C $t "cwf_pt_course_code"    "Course Code"        "String"
C $t "cwf_pt_status"         "Training Status"    "Choice"   $true  "cwf_training_status"
C $t "cwf_pt_start_date"     "Start Date"         "DateTime"
C $t "cwf_pt_comp_date"      "Completion Date"    "DateTime"
C $t "cwf_pt_exp_date"       "Expiration Date"    "DateTime"
C $t "cwf_pt_hours"          "Hours Completed"    "Integer"
C $t "cwf_pt_cert_url"       "Certificate URL"    "Url"
C $t "cwf_pt_notes"          "Notes"              "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 8: cwf_saar
# ══════════════════════════════════════════════════════════════
$t = "cwf_saar"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_saar_requestor"     "Requestor Name"           "String"   $true
C $t "cwf_saar_dod_id"        "Requestor DoD ID"         "String"   $true
C $t "cwf_saar_email"         "Requestor Email"          "Email"    $true
C $t "cwf_saar_system"        "System Name"              "String"   $true
C $t "cwf_saar_access_type"   "Access Type"              "Choice"   $false "cwf_access_type"
C $t "cwf_saar_justification" "Justification"            "Memo"     $true
C $t "cwf_saar_wf_status"     "SAAR Workflow Status"     "Choice"   $true  "cwf_saar_status"
C $t "cwf_saar_sup_date"      "Supervisor Approval Date" "DateTime"
C $t "cwf_saar_ia_date"       "IA Approval Date"         "DateTime"
C $t "cwf_saar_request_date"  "Request Date"             "DateTime" $true
C $t "cwf_saar_exp_date"      "Expiration Date"          "DateTime"
C $t "cwf_saar_cyber_train"   "Cyber Training Complete"  "Boolean"
C $t "cwf_saar_aup_signed"    "AUP Signed"              "Boolean"
C $t "cwf_saar_notes"         "Notes"                    "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 9: cwf_stig_compliance
# ══════════════════════════════════════════════════════════════
$t = "cwf_stig_compliance"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_stig_id"           "STIG ID"            "String"   $true
C $t "cwf_stig_title"        "STIG Title"         "String"   $true
C $t "cwf_stig_severity"     "Severity"           "Choice"   $true  "cwf_severity"
C $t "cwf_stig_check_status" "Check Status"       "Choice"   $true  "cwf_check_status"
C $t "cwf_stig_system"       "System"             "String"
C $t "cwf_stig_rule_id"      "Rule ID"            "String"
C $t "cwf_stig_fix_text"     "Fix Text"           "Memo"
C $t "cwf_stig_check_text"   "Check Text"         "Memo"
C $t "cwf_stig_finding"      "Finding Details"    "Memo"
C $t "cwf_stig_review_date"  "Review Date"        "DateTime"
C $t "cwf_stig_poam_req"     "POA&M Required"     "Boolean"

# ══════════════════════════════════════════════════════════════
# TABLE 10: cwf_poam
# ══════════════════════════════════════════════════════════════
$t = "cwf_poam"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_poam_id"            "POAM ID"              "String"   $true
C $t "cwf_poam_weakness"      "Weakness"             "Memo"     $true
C $t "cwf_poam_stig_id"       "Related STIG"         "String"
C $t "cwf_poam_severity"      "Severity"             "Choice"   $false "cwf_severity"
C $t "cwf_poam_milestone"     "Milestone"            "Memo"
C $t "cwf_poam_status"        "Process Status"       "Choice"   $true  "cwf_process_status"
C $t "cwf_poam_sched_date"    "Scheduled Completion" "DateTime" $true
C $t "cwf_poam_actual_date"   "Actual Completion"    "DateTime"
C $t "cwf_poam_risk_accepted" "Risk Accepted"        "Boolean"
C $t "cwf_poam_notes"         "Notes"                "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 11: cwf_systems
# ══════════════════════════════════════════════════════════════
$t = "cwf_systems"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_sys_name"           "System Name"       "String"   $true
C $t "cwf_sys_acronym"        "System Acronym"    "String"
C $t "cwf_sys_emass_id"       "eMASS ID"          "String"
C $t "cwf_sys_ato_status"     "ATO Status"        "Choice"   $false "cwf_ato_status"
C $t "cwf_sys_ato_exp"        "ATO Expiration"    "DateTime"
C $t "cwf_sys_classification" "Classification"    "Choice"   $false "cwf_classification"
C $t "cwf_sys_description"    "Description"       "Memo"
C $t "cwf_sys_active"         "Active"            "Boolean"

# ══════════════════════════════════════════════════════════════
# TABLE 12: cwf_waivers
# ══════════════════════════════════════════════════════════════
$t = "cwf_waivers"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_waiver_id"            "Waiver ID"             "String"   $true
C $t "cwf_waiver_personnel"     "Personnel Name"        "String"   $true
C $t "cwf_waiver_dod_id"        "Personnel DoD ID"      "String"
C $t "cwf_waiver_type"          "Waiver Type"           "String"
C $t "cwf_waiver_justification" "Justification"         "Memo"     $true
C $t "cwf_waiver_approval"      "Approval Status"       "Choice"   $true  "cwf_approval_status"
C $t "cwf_waiver_req_date"      "Request Date"          "DateTime" $true
C $t "cwf_waiver_appr_date"     "Approval Date"         "DateTime"
C $t "cwf_waiver_exp_date"      "Expiration Date"       "DateTime"
C $t "cwf_waiver_notes"         "Notes"                 "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 13: cwf_audit_log
# ══════════════════════════════════════════════════════════════
$t = "cwf_audit_log"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_audit_action"       "Action"           "Choice"   $true  "cwf_workflow_stage"
C $t "cwf_audit_entity_type"  "Entity Type"      "String"
C $t "cwf_audit_record_id"    "Record ID"        "String"
C $t "cwf_audit_record_title" "Record Title"     "String"
C $t "cwf_audit_timestamp"    "Timestamp"        "DateTime" $true
C $t "cwf_audit_prev_value"   "Previous Value"   "Memo"
C $t "cwf_audit_new_value"    "New Value"        "Memo"
C $t "cwf_audit_notes"        "Notes"            "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 14: cwf_notifications
# ══════════════════════════════════════════════════════════════
$t = "cwf_notifications"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_notif_type"      "Notification Type"  "String"   $true
C $t "cwf_notif_email"     "Recipient Email"    "Email"
C $t "cwf_notif_subject"   "Subject"            "String"   $true
C $t "cwf_notif_message"   "Message"            "Memo"
C $t "cwf_notif_related"   "Related Record"     "String"
C $t "cwf_notif_sent_date" "Sent Date"          "DateTime"
C $t "cwf_notif_read"      "Read"               "Boolean"
C $t "cwf_notif_priority"  "Priority"           "Choice"   $false "cwf_priority"

# ══════════════════════════════════════════════════════════════
# TABLE 15: cwf_compliance_reports
# ══════════════════════════════════════════════════════════════
$t = "cwf_compliance_reports"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_rpt_name"          "Report Name"          "String"   $true
C $t "cwf_rpt_type"          "Report Type"          "String"
C $t "cwf_rpt_gen_date"      "Generated Date"       "DateTime" $true
C $t "cwf_rpt_period_start"  "Period Start"         "DateTime"
C $t "cwf_rpt_period_end"    "Period End"           "DateTime"
C $t "cwf_rpt_total"         "Total Personnel"      "Integer"
C $t "cwf_rpt_compliant"     "Compliant Count"      "Integer"
C $t "cwf_rpt_non_compliant" "Non-Compliant Count"  "Integer"
C $t "cwf_rpt_pct"           "Compliance %"         "Decimal"
C $t "cwf_rpt_url"           "Report URL"           "Url"
C $t "cwf_rpt_notes"         "Notes"                "Memo"

# ══════════════════════════════════════════════════════════════
# TABLE 16: cwf_configuration
# ══════════════════════════════════════════════════════════════
$t = "cwf_configuration"
Write-Host "`n┌── $t ──┐" -ForegroundColor Cyan
C $t "cwf_config_name"        "Setting Name"       "String"   $true
C $t "cwf_config_value"       "Setting Value"      "Memo"     $true
C $t "cwf_config_category"    "Setting Category"   "String"
C $t "cwf_config_description" "Description"        "Memo"
C $t "cwf_config_data_type"   "Data Type"          "String"
C $t "cwf_config_mod_date"    "Last Modified Date" "DateTime"

# ══════════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════════
Write-Host "`n══════════════════════════════════════════════════════════" -ForegroundColor $(if ($script:errCount -eq 0) {"Green"} else {"Yellow"})
Write-Host "  COLUMN CREATION COMPLETE" -ForegroundColor $(if ($script:errCount -eq 0) {"Green"} else {"Yellow"})
Write-Host "══════════════════════════════════════════════════════════" -ForegroundColor $(if ($script:errCount -eq 0) {"Green"} else {"Yellow"})
Write-Host "  Columns processed: $($script:colCount)" -ForegroundColor Cyan
Write-Host "  Errors:            $($script:errCount)" -ForegroundColor $(if ($script:errCount -eq 0) {"Green"} else {"Red"})
Write-Host "  All names:         lowercase_underscore (cwf_*)" -ForegroundColor Green
Write-Host "  Choice columns:    bound to global choice sets from Step 3" -ForegroundColor Green
Write-Host ""

Write-Host "  IMPORTANT: Add columns to your solution:" -ForegroundColor Yellow
Write-Host "  make.powerapps.com > Solutions > $($config.solution.display_name)" -ForegroundColor White
Write-Host "  > Tables > each table > Include all components" -ForegroundColor White
Write-Host ""

$global:CWF_DV_CONN = $conn
