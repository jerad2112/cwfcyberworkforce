<#
.SYNOPSIS
    CWF Dataverse Pipeline Step 4: Create Tables (Entities)
.DESCRIPTION
    Creates all 16 CWF tables in Dataverse via Web API.
    All table names use lowercase_underscore with cwf_ prefix.
    Tables are created as user-owned with standard activity tracking.
    
    TABLES CREATED:
    cwf_personnel, cwf_work_roles, cwf_work_role_assignments,
    cwf_certifications, cwf_personnel_certifications, cwf_training,
    cwf_personnel_training, cwf_saar, cwf_stig_compliance,
    cwf_poam, cwf_systems, cwf_waivers, cwf_audit_log,
    cwf_notifications, cwf_compliance_reports, cwf_configuration
.PARAMETER ConfigPath
    Path to dv_config.json
.EXAMPLE
    .\04_create_tables.ps1 -ConfigPath .\dv_config.json
#>
param([Parameter(Mandatory=$true)][string]$ConfigPath, [switch]$WhatIf)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF DATAVERSE PIPELINE - Step 4: Create Tables" -ForegroundColor Cyan
Write-Host "  Naming: cwf_[name] lowercase_underscore" -ForegroundColor Gray
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$envUrl = $config.environment.url
$prefix = $config.publisher.prefix

$conn = if ($global:CWF_DV_CONN -and $global:CWF_DV_CONN.IsReady) {
    Write-Host "  [REUSED] Existing connection" -ForegroundColor Green
    $global:CWF_DV_CONN
} else {
    Write-Host "  Connecting to: $envUrl" -ForegroundColor Gray
    Connect-CrmOnline -ServerUrl $envUrl -ForceOAuth
}

$baseUrl = "$envUrl/api/data/v9.2"

function Get-AuthHeaders {
    return @{
        "Authorization"    = "Bearer $($conn.CurrentAccessToken)"
        "Content-Type"     = "application/json"
        "OData-MaxVersion" = "4.0"
        "OData-Version"    = "4.0"
    }
}

function New-DVTable {
    param(
        [string]$SchemaName,
        [string]$DisplayName,
        [string]$PluralName,
        [string]$Description,
        [string]$PrimaryField = "cwf_name"
    )
    
    Write-Host "`n  ── $SchemaName ──" -ForegroundColor White
    
    # Check if exists
    try {
        $check = Invoke-RestMethod -Uri "$baseUrl/EntityDefinitions(LogicalName='$SchemaName')" `
            -Headers (Get-AuthHeaders) -Method Get -ErrorAction Stop
        Write-Host "    [EXISTS] $($check.DisplayName.UserLocalizedLabel.Label)" -ForegroundColor DarkYellow
        return "exists"
    } catch {}
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create: $DisplayName" -ForegroundColor DarkYellow
        return "whatif"
    }
    
    $body = @{
        "@odata.type"                = "Microsoft.Dynamics.CRM.EntityMetadata"
        SchemaName                   = $SchemaName
        DisplayName                  = @{
            "@odata.type"    = "Microsoft.Dynamics.CRM.Label"
            LocalizedLabels  = @(@{ "@odata.type"="Microsoft.Dynamics.CRM.LocalizedLabel"; Label=$DisplayName; LanguageCode=1033 })
        }
        DisplayCollectionName        = @{
            "@odata.type"    = "Microsoft.Dynamics.CRM.Label"
            LocalizedLabels  = @(@{ "@odata.type"="Microsoft.Dynamics.CRM.LocalizedLabel"; Label=$PluralName; LanguageCode=1033 })
        }
        Description                  = @{
            "@odata.type"    = "Microsoft.Dynamics.CRM.Label"
            LocalizedLabels  = @(@{ "@odata.type"="Microsoft.Dynamics.CRM.LocalizedLabel"; Label=$Description; LanguageCode=1033 })
        }
        OwnershipType                = "UserOwned"
        IsActivity                   = $false
        HasActivities                = $false
        HasNotes                     = $true
        IsAuditEnabled               = @{ Value = $true; CanBeChanged = $true }
        PrimaryNameAttribute         = $PrimaryField
        Attributes = @(
            @{
                "@odata.type"        = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
                AttributeType        = "String"
                AttributeTypeName    = @{ Value = "StringType" }
                SchemaName           = $PrimaryField
                MaxLength            = 200
                FormatName           = @{ Value = "Text" }
                DisplayName          = @{
                    "@odata.type"    = "Microsoft.Dynamics.CRM.Label"
                    LocalizedLabels  = @(@{ "@odata.type"="Microsoft.Dynamics.CRM.LocalizedLabel"; Label="Name"; LanguageCode=1033 })
                }
                IsPrimaryName        = $true
                RequiredLevel        = @{ Value = "ApplicationRequired"; CanBeChanged = $true }
            }
        )
    } | ConvertTo-Json -Depth 15
    
    try {
        $result = Invoke-RestMethod -Uri "$baseUrl/EntityDefinitions" `
            -Headers (Get-AuthHeaders) -Method Post -Body $body
        Write-Host "    [CREATED] $DisplayName" -ForegroundColor Green
        return "created"
    } catch {
        $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $msg = if ($err) { $err.error.message } else { $_.Exception.Message }
        Write-Host "    [ERROR] $msg" -ForegroundColor Red
        return "error"
    }
}

$tableInventory = @()

# ══════════════════════════════════════════════════════════════
# CREATE ALL 16 TABLES
# ══════════════════════════════════════════════════════════════

$tables = @(
    @{ schema="cwf_personnel";                  display="Personnel";                  plural="Personnel Records";                 desc="Personnel records for CWF compliance tracking"; primary="cwf_name" },
    @{ schema="cwf_work_roles";                 display="Work Role";                  plural="Work Roles";                        desc="DoD 8140 DCWF work role definitions"; primary="cwf_name" },
    @{ schema="cwf_work_role_assignments";      display="Work Role Assignment";       plural="Work Role Assignments";             desc="Maps personnel to assigned work roles"; primary="cwf_name" },
    @{ schema="cwf_certifications";             display="Certification";              plural="Certifications";                    desc="Approved certification catalog"; primary="cwf_name" },
    @{ schema="cwf_personnel_certifications";   display="Personnel Certification";    plural="Personnel Certifications";          desc="Certifications held per person"; primary="cwf_name" },
    @{ schema="cwf_training";                   display="Training Course";            plural="Training Courses";                  desc="Training course catalog"; primary="cwf_name" },
    @{ schema="cwf_personnel_training";         display="Personnel Training";         plural="Personnel Training Records";        desc="Training completion per person"; primary="cwf_name" },
    @{ schema="cwf_saar";                       display="SAAR";                       plural="SAARs";                             desc="System Authorization Access Requests (DD 2875)"; primary="cwf_name" },
    @{ schema="cwf_stig_compliance";            display="STIG Compliance";            plural="STIG Compliance Records";           desc="STIG checklist items and compliance tracking"; primary="cwf_name" },
    @{ schema="cwf_poam";                       display="POA&M";                      plural="POA&M Records";                     desc="Plan of Action and Milestones"; primary="cwf_name" },
    @{ schema="cwf_systems";                    display="System";                     plural="Systems";                           desc="Information systems inventory"; primary="cwf_name" },
    @{ schema="cwf_waivers";                    display="Waiver";                     plural="Waivers";                           desc="Compliance waivers and exceptions"; primary="cwf_name" },
    @{ schema="cwf_audit_log";                  display="Audit Log Entry";            plural="Audit Log";                         desc="Compliance action audit trail"; primary="cwf_name" },
    @{ schema="cwf_notifications";              display="Notification";               plural="Notifications";                     desc="Automated compliance notifications"; primary="cwf_name" },
    @{ schema="cwf_compliance_reports";         display="Compliance Report";          plural="Compliance Reports";                desc="Generated compliance report snapshots"; primary="cwf_name" },
    @{ schema="cwf_configuration";              display="Configuration Setting";      plural="Configuration Settings";            desc="Portal configuration settings"; primary="cwf_name" }
)

foreach ($t in $tables) {
    $result = New-DVTable -SchemaName $t.schema -DisplayName $t.display `
        -PluralName $t.plural -Description $t.desc -PrimaryField $t.primary
    
    $tableInventory += [PSCustomObject]@{
        table_name   = $t.schema
        display_name = $t.display
        plural_name  = $t.plural
        status       = $result
    }
}

# ══════════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════════
$created = ($tableInventory | Where-Object { $_.status -eq "created" }).Count
$existed = ($tableInventory | Where-Object { $_.status -eq "exists" }).Count
$failed = ($tableInventory | Where-Object { $_.status -eq "error" }).Count

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor $(if ($failed -eq 0) {"Green"} else {"Yellow"})
Write-Host "  TABLE CREATION COMPLETE" -ForegroundColor $(if ($failed -eq 0) {"Green"} else {"Yellow"})
Write-Host "══════════════════════════════════════════════════" -ForegroundColor $(if ($failed -eq 0) {"Green"} else {"Yellow"})
Write-Host "  Created:  $created" -ForegroundColor Green
Write-Host "  Existed:  $existed" -ForegroundColor DarkYellow
Write-Host "  Failed:   $failed" -ForegroundColor $(if ($failed -eq 0) {"Green"} else {"Red"})
Write-Host "  Total:    $($tables.Count)" -ForegroundColor Cyan
Write-Host ""

$tableInventory | Export-Csv -Path ".\dv_04_tables.csv" -NoTypeInformation
Write-Host "  Inventory: dv_04_tables.csv" -ForegroundColor Gray

Write-Host "`n  IMPORTANT: Add tables to your solution:" -ForegroundColor Yellow
Write-Host "  make.powerapps.com > Solutions > $($config.solution.display_name)" -ForegroundColor White
Write-Host "  > Add existing > Table > select all cwf_* tables" -ForegroundColor White
Write-Host "  > Include: Table metadata + All components" -ForegroundColor White
Write-Host ""

$global:CWF_DV_CONN = $conn
