# CWF Deployment Pipeline - Complete Setup Guide
# ================================================
# Version: 3.0 | Environment: GCC (.mil.us)
# Naming Convention: lowercase_underscore for all lists and columns
#
# WHAT TO FEED INTO ASKSAGE:
# ─────────────────────────
# AskSage needs the following information to customize these scripts
# for your specific organization. Copy the sections below into AskSage
# and provide the values for each placeholder.
#
# ┌──────────────────────────────────────────────────────────────┐
# │  INFORMATION NEEDED FROM YOU                                 │
# │                                                              │
# │  1. TENANT DOMAIN                                           │
# │     Example: armyeitaas.sharepoint-mil.us                   │
# │     Your value: ________________________________________    │
# │                                                              │
# │  2. ADMIN SITE URL                                          │
# │     Example: https://armyeitaas-admin.sharepoint-mil.us     │
# │     Your value: ________________________________________    │
# │                                                              │
# │  3. YOUR ADMIN UPN (email for site ownership)               │
# │     Example: john.doe.civ@mail.mil                          │
# │     Your value: ________________________________________    │
# │                                                              │
# │  4. HUB SITE URL (where you want the main hub)              │
# │     Example: https://armyeitaas.sharepoint-mil.us/sites/    │
# │              CWF-TACOM-HUB                                  │
# │     Your value: ________________________________________    │
# │                                                              │
# │  5. SITE PREFIX (short code for all site URLs)              │
# │     Example: CWF-TACOM                                      │
# │     Your value: ________________________________________    │
# │                                                              │
# │  6. MSC/ORGANIZATION NAME                                   │
# │     Example: TACOM                                          │
# │     Your value: ________________________________________    │
# │                                                              │
# │  7. NOTIFICATION DISTRIBUTION LIST                          │
# │     Example: TACOM-G6-CWF@mail.mil                         │
# │     Your value: ________________________________________    │
# │                                                              │
# │  8. INSTALLATIONS (one per line):                           │
# │     Format: CODE | Full Name                                │
# │     Example:                                                │
# │       DTA  | Detroit Arsenal                                │
# │       RRAD | Red River Army Depot                           │
# │       SIAD | Sierra Army Depot                              │
# │     Your installations:                                     │
# │     _____ | ________________________________________        │
# │     _____ | ________________________________________        │
# │     _____ | ________________________________________        │
# │                                                              │
# │  9. DIRECTORATES PER INSTALLATION:                          │
# │     Format: CODE | Full Name                                │
# │     Example (these repeat for each installation):           │
# │       G1 | G-1 Manpower                                    │
# │       G2 | G-2 Intelligence                                │
# │       G3 | G-3 Operations                                  │
# │       G6 | G-6 Cyber & IT                                  │
# │     Your directorates:                                      │
# │     _____ | ________________________________________        │
# │     _____ | ________________________________________        │
# │                                                              │
# │ 10. TEAMS CHANNEL URL (for compliance alerts, optional)     │
# │     Your value: ________________________________________    │
# │                                                              │
# └──────────────────────────────────────────────────────────────┘
#
# PIPELINE EXECUTION ORDER:
# ─────────────────────────
# Step 1: Edit cwf_config.json with your values (or use AskSage)
# Step 2: Run 01_validate_config.ps1 -ConfigPath .\cwf_config.json
# Step 3: Run 02_create_sites.ps1 -ConfigPath .\cwf_config.json -Diagnose
# Step 4: Run 02_create_sites.ps1 -ConfigPath .\cwf_config.json
# Step 5: Run 03_create_lists.ps1 (loop through inventory - see below)
# Step 6: Run 04_repair_failed.ps1 (if any failures)
# Step 7: Run 05_configure_permissions.ps1 -ConfigPath .\cwf_config.json
# Step 8: Run 06_deploy_flows.ps1 -ConfigPath .\cwf_config.json
# Step 9: Run 07_populate_master_data.ps1 -ConfigPath .\cwf_config.json
# Step 10: Run 08_validate_deployment.ps1 -ConfigPath .\cwf_config.json
#
# STEP 5 DETAIL (loop through all sites):
#   $sites = Import-Csv .\sharepoint_sites_inventory.csv
#   foreach ($site in ($sites | Where-Object { $_.Status -eq "Success" })) {
#       .\03_create_lists.ps1 -SiteUrl $site.Url
#   }
#
# NAMING CONVENTION:
# ─────────────────
# All list names:   cwf_[name]          (e.g., cwf_personnel, cwf_work_roles)
# All column names: cwf_[context]_[name] (e.g., cwf_first_name, cwf_wr_category)
# All SP groups:    cwf-[scope]-[role]   (e.g., cwf-msc-admins, cwf-dta-editors)
# All flow names:   cwf_[type]_[name]    (e.g., cwf_sync_personnel, cwf_notify_cert_expiration)
