<#
.SYNOPSIS
    CWF Pipeline Step 3: Create Lists & Columns (lowercase_underscore)
.DESCRIPTION
    Creates all 16 CWF lists with lowercase_underscore naming convention.
    All columns auto-added to default view via -AddToDefaultView flag.
    
    LIST NAMING: cwf_[name] (e.g., cwf_personnel, cwf_work_roles)
    COLUMN NAMING: cwf_[name] (e.g., cwf_first_name, cwf_dod_id)
.PARAMETER SiteUrl
    SharePoint site URL to create lists on
.PARAMETER WhatIf
    Preview without creating
.EXAMPLE
    .\03_create_lists.ps1 -SiteUrl "https://armyeitaas.sharepoint-mil.us/sites/CWF-TACOM-HUB"
    
    # Loop through all sites from inventory:
    Import-Csv .\sharepoint_sites_inventory.csv |
      Where-Object { $_.status -eq "Success" } |
      ForEach-Object { .\03_create_lists.ps1 -SiteUrl $_.url }
#>
param(
    [Parameter(Mandatory=$true)][string]$SiteUrl,
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF PIPELINE - Step 3: Create Lists & Columns" -ForegroundColor Cyan
Write-Host "  Naming: lowercase_underscore" -ForegroundColor Gray
Write-Host "══════════════════════════════════════════════════`n" -ForegroundColor Cyan

# ── Connect ──
$pnpEnv = if ($SiteUrl -match "\.us") { "USGovernment" } else { "Production" }
Write-Host "  Connecting to: $SiteUrl" -ForegroundColor Gray
if ($pnpEnv -eq "Production") { Connect-PnPOnline -Url $SiteUrl -Interactive }
else { Connect-PnPOnline -Url $SiteUrl -Interactive -Environment $pnpEnv }
Write-Host "  [CONNECTED]`n" -ForegroundColor Green

# ══════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════
function New-List {
    param([string]$n, [string]$d)
    Write-Host "`n┌── LIST: $n ──┐" -ForegroundColor Cyan
    if ($WhatIf) { Write-Host "  [WhatIf] $n" -ForegroundColor DarkYellow; return }
    $x = Get-PnPList -Identity $n -ErrorAction SilentlyContinue
    if ($x) { Write-Host "  [EXISTS] $n" -ForegroundColor DarkYellow; return }
    New-PnPList -Title $n -Template GenericList -EnableVersioning
    Write-Host "  [CREATED] $n" -ForegroundColor Green
}

function Add-Col {
    param(
        [string]$l, [string]$dn, [string]$in,
        [string]$t="Text", [bool]$r=$false, [string[]]$ch=@()
    )
    if ($WhatIf) { Write-Host "  [WhatIf] $dn ($t)" -ForegroundColor DarkYellow; return }
    $x = Get-PnPField -List $l -Identity $in -ErrorAction SilentlyContinue
    if ($x) { Write-Host "  [EXISTS] $dn" -ForegroundColor DarkYellow; return }
    try {
        switch ($t) {
            "Choice"      { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type Choice -Choices $ch -Required:$r -AddToDefaultView }
            "MultiChoice" { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type MultiChoice -Choices $ch -Required:$r -AddToDefaultView }
            "Note"        { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type Note -Required:$r -AddToDefaultView }
            "DateTime"    { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type DateTime -Required:$r -AddToDefaultView }
            "Number"      { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type Number -Required:$r -AddToDefaultView }
            "Boolean"     { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type Boolean -Required:$r -AddToDefaultView }
            "User"        { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type User -Required:$r -AddToDefaultView }
            "URL"         { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type URL -Required:$r -AddToDefaultView }
            default       { Add-PnPField -List $l -DisplayName $dn -InternalName $in -Type Text -Required:$r -AddToDefaultView }
        }
        Write-Host "  [ADDED] $dn ($t)" -ForegroundColor Green
    } catch { Write-Host "  [ERROR] $dn - $($_.Exception.Message)" -ForegroundColor Red }
}

# ══════════════════════════════════════════════════════════════
# SHARED CHOICES (lowercase labels for consistency)
# ══════════════════════════════════════════════════════════════
$ch_status = @("Active","Inactive","Pending","Archived")
$ch_priority = @("Critical","High","Medium","Low")
$ch_approval = @("Draft","Submitted","Approved","Rejected","Returned")
$ch_workflow = @("Draft","In Progress","Pending Review","Approved","Archived")
$ch_process = @("Not Started","In Progress","Pending Approval","Completed","Cancelled")
$ch_compliance = @("Compliant","Non-Compliant","Partially Compliant","Exempt","Pending Review")
$ch_cert_status = @("Active","Expired","Pending","Revoked","Suspended")
$ch_training_cat = @("Foundational","Resident","Core","Elective","Continuous Learning")
$ch_training_status = @("Not Started","In Progress","Completed","Expired","Waived")
$ch_saar_status = @("Draft","Submitted","Supervisor Approved","IA Approved","Rejected","Returned","Revoked")
$ch_wr_category = @("Securely Provision","Operate and Maintain","Oversee and Govern","Protect and Defend","Analyze","Collect and Operate","Investigate")
$ch_rank = @("E1","E2","E3","E4","E5","E6","E7","E8","E9","W1","W2","W3","W4","W5","O1","O2","O3","O4","O5","O6","O7","O8","O9","O10","GS-05","GS-07","GS-09","GS-11","GS-12","GS-13","GS-14","GS-15","SES","CTR")
$ch_clearance = @("None","Confidential","Secret","Top Secret","TS/SCI")
$ch_severity = @("CAT I","CAT II","CAT III")
$ch_check_status = @("Not Reviewed","Not Applicable","Open","Not a Finding")
$ch_sensitivity_cat = @("Uncontrolled","Controlled - Collaboration")
$ch_sensitivity_sub = @("General","Secured (Any)","Secured (Internal Only)","Recipients Only","CUI","CUI - Secured (Internal Only)","CUI - Recipients Only","CUI - DoD Community Only")
$ch_delivery = @("Online","In-Person","Hybrid","Self-Paced")
$ch_access_type = @("New Access","Modify","Remove","Renewal")
$ch_waiver_type = @("Certification","Training","Qualification","Experience","Other")
$ch_notif_type = @("Expiration Warning","Overdue","Action Required","Approval Needed","Compliance Alert","Informational")
$ch_audit_action = @("Created","Updated","Deleted","Approved","Rejected","Waived","Expired","Renewed")
$ch_audit_entity = @("Personnel","Certification","Training","SAAR","WorkRole","Waiver","STIG","POAM","System")
$ch_report_type = @("Individual Compliance","Unit Summary","STIG Summary","Training Status","Certification Expiry","SAAR Status","Executive Dashboard")
$ch_ato_status = @("Active ATO","Conditional ATO","IATT","Denied","Pending","Expired")
$ch_classification = @("Unclassified","CUI","Secret","Top Secret")
$ch_config_cat = @("General","Notifications","Compliance Rules","Thresholds","Integration","Security")
$ch_config_dtype = @("Text","Number","Boolean","Date","URL","JSON")

$inv = @()

# ══════════════════════════════════════════════════════════════
# LIST 1: cwf_personnel
# ══════════════════════════════════════════════════════════════
New-List "cwf_personnel" "Personnel records for CWF compliance tracking"
Add-Col "cwf_personnel" "First Name"         "cwf_first_name"         "Text"     $true
Add-Col "cwf_personnel" "Last Name"          "cwf_last_name"          "Text"     $true
Add-Col "cwf_personnel" "DoD ID"             "cwf_dod_id"             "Text"     $true
Add-Col "cwf_personnel" "Email"              "cwf_email"              "Text"     $true
Add-Col "cwf_personnel" "Phone"              "cwf_phone"              "Text"
Add-Col "cwf_personnel" "Rank/Grade"         "cwf_rank"               "Choice"   $true  $ch_rank
Add-Col "cwf_personnel" "Organization"       "cwf_organization"       "Text"     $true
Add-Col "cwf_personnel" "Duty Position"      "cwf_duty_position"      "Text"
Add-Col "cwf_personnel" "Supervisor"         "cwf_supervisor"         "User"
Add-Col "cwf_personnel" "Supervisor Email"   "cwf_supervisor_email"   "Text"
Add-Col "cwf_personnel" "Clearance Level"    "cwf_clearance"          "Choice"   $false $ch_clearance
Add-Col "cwf_personnel" "Compliance Status"  "cwf_compliance_status"  "Choice"   $false $ch_compliance
Add-Col "cwf_personnel" "Personnel Status"   "cwf_personnel_status"   "Choice"   $true  $ch_status
Add-Col "cwf_personnel" "Onboard Date"       "cwf_onboard_date"       "DateTime"
Add-Col "cwf_personnel" "Separation Date"    "cwf_separation_date"    "DateTime"
Add-Col "cwf_personnel" "Sensitivity"        "cwf_sensitivity_cat"    "Choice"   $false $ch_sensitivity_cat
Add-Col "cwf_personnel" "Sensitivity Label"  "cwf_sensitivity_label"  "Choice"   $false $ch_sensitivity_sub
Add-Col "cwf_personnel" "Notes"              "cwf_notes"              "Note"
$inv += [PSCustomObject]@{list="cwf_personnel";columns=18;description="Personnel records"}

# ══════════════════════════════════════════════════════════════
# LIST 2: cwf_work_roles
# ══════════════════════════════════════════════════════════════
New-List "cwf_work_roles" "DoD 8140 DCWF work role definitions"
Add-Col "cwf_work_roles" "Work Role ID"           "cwf_wr_id"              "Text"    $true
Add-Col "cwf_work_roles" "Work Role Name"          "cwf_wr_name"            "Text"    $true
Add-Col "cwf_work_roles" "Work Role Category"      "cwf_wr_category"        "Choice"  $true  $ch_wr_category
Add-Col "cwf_work_roles" "NICE Framework ID"       "cwf_wr_nice_id"         "Text"
Add-Col "cwf_work_roles" "Description"             "cwf_wr_description"     "Note"
Add-Col "cwf_work_roles" "Required Certifications" "cwf_wr_required_certs"  "Note"
Add-Col "cwf_work_roles" "Foundational Qual"       "cwf_wr_foundational"    "Text"
Add-Col "cwf_work_roles" "Resident Course"         "cwf_wr_resident"        "Text"
Add-Col "cwf_work_roles" "Active"                  "cwf_wr_active"          "Boolean"
$inv += [PSCustomObject]@{list="cwf_work_roles";columns=9;description="DCWF work role definitions"}

# ══════════════════════════════════════════════════════════════
# LIST 3: cwf_work_role_assignments
# ══════════════════════════════════════════════════════════════
New-List "cwf_work_role_assignments" "Maps personnel to assigned work roles"
Add-Col "cwf_work_role_assignments" "Personnel Name"      "cwf_wra_personnel_name" "Text"    $true
Add-Col "cwf_work_role_assignments" "Personnel DoD ID"    "cwf_wra_dod_id"         "Text"    $true
Add-Col "cwf_work_role_assignments" "Work Role"           "cwf_wra_work_role"      "Text"    $true
Add-Col "cwf_work_role_assignments" "Work Role ID"        "cwf_wra_work_role_id"   "Text"
Add-Col "cwf_work_role_assignments" "Primary Role"        "cwf_wra_primary"        "Boolean"
Add-Col "cwf_work_role_assignments" "Assignment Date"     "cwf_wra_assign_date"    "DateTime" $true
Add-Col "cwf_work_role_assignments" "Qualification Status" "cwf_wra_qual_status"   "Choice"  $false $ch_compliance
Add-Col "cwf_work_role_assignments" "Qualification Date"  "cwf_wra_qual_date"      "DateTime"
Add-Col "cwf_work_role_assignments" "Expiration Date"     "cwf_wra_exp_date"       "DateTime"
Add-Col "cwf_work_role_assignments" "Notes"               "cwf_wra_notes"          "Note"
$inv += [PSCustomObject]@{list="cwf_work_role_assignments";columns=10;description="Personnel-to-work-role mapping"}

# ══════════════════════════════════════════════════════════════
# LIST 4: cwf_certifications
# ══════════════════════════════════════════════════════════════
New-List "cwf_certifications" "Approved certification catalog"
Add-Col "cwf_certifications" "Certification Name"   "cwf_cert_name"        "Text"    $true
Add-Col "cwf_certifications" "Certification Code"   "cwf_cert_code"        "Text"    $true
Add-Col "cwf_certifications" "Issuing Body"         "cwf_cert_issuing_body" "Text"   $true
Add-Col "cwf_certifications" "DoD 8140 Approved"    "cwf_cert_dod_approved" "Boolean"
Add-Col "cwf_certifications" "Validity (Months)"    "cwf_cert_validity_months" "Number"
Add-Col "cwf_certifications" "CE Required"          "cwf_cert_ce_required"  "Boolean"
Add-Col "cwf_certifications" "CE Hours Required"    "cwf_cert_ce_hours"     "Number"
Add-Col "cwf_certifications" "Mapped Work Roles"    "cwf_cert_mapped_wr"    "Note"
Add-Col "cwf_certifications" "Description"          "cwf_cert_description"  "Note"
Add-Col "cwf_certifications" "Active"               "cwf_cert_active"       "Boolean"
$inv += [PSCustomObject]@{list="cwf_certifications";columns=10;description="Approved cert catalog"}

# ══════════════════════════════════════════════════════════════
# LIST 5: cwf_personnel_certifications
# ══════════════════════════════════════════════════════════════
New-List "cwf_personnel_certifications" "Certifications held per person"
Add-Col "cwf_personnel_certifications" "Personnel Name"     "cwf_pc_personnel_name" "Text"    $true
Add-Col "cwf_personnel_certifications" "Personnel DoD ID"   "cwf_pc_dod_id"         "Text"    $true
Add-Col "cwf_personnel_certifications" "Certification"      "cwf_pc_cert_name"      "Text"    $true
Add-Col "cwf_personnel_certifications" "Certification Code" "cwf_pc_cert_code"      "Text"
Add-Col "cwf_personnel_certifications" "Date Earned"        "cwf_pc_date_earned"    "DateTime" $true
Add-Col "cwf_personnel_certifications" "Expiration Date"    "cwf_pc_exp_date"       "DateTime"
Add-Col "cwf_personnel_certifications" "Cert Status"        "cwf_pc_cert_status"    "Choice"  $true  $ch_cert_status
Add-Col "cwf_personnel_certifications" "Certificate Number" "cwf_pc_cert_number"    "Text"
Add-Col "cwf_personnel_certifications" "Verification URL"   "cwf_pc_verify_url"     "URL"
Add-Col "cwf_personnel_certifications" "CE Hours Completed" "cwf_pc_ce_completed"   "Number"
Add-Col "cwf_personnel_certifications" "Notes"              "cwf_pc_notes"          "Note"
$inv += [PSCustomObject]@{list="cwf_personnel_certifications";columns=11;description="Personnel cert records"}

# ══════════════════════════════════════════════════════════════
# LIST 6: cwf_training
# ══════════════════════════════════════════════════════════════
New-List "cwf_training" "Training course catalog"
Add-Col "cwf_training" "Course Name"          "cwf_tr_course_name"     "Text"    $true
Add-Col "cwf_training" "Course Code"          "cwf_tr_course_code"     "Text"
Add-Col "cwf_training" "Training Category"    "cwf_tr_category"        "Choice"  $true  $ch_training_cat
Add-Col "cwf_training" "Provider"             "cwf_tr_provider"        "Text"
Add-Col "cwf_training" "Duration (Hours)"     "cwf_tr_duration"        "Number"
Add-Col "cwf_training" "Delivery Method"      "cwf_tr_delivery"        "Choice"  $false $ch_delivery
Add-Col "cwf_training" "Mapped Work Roles"    "cwf_tr_mapped_wr"       "Note"
Add-Col "cwf_training" "DoD 8140 Approved"    "cwf_tr_dod_approved"    "Boolean"
Add-Col "cwf_training" "URL"                  "cwf_tr_url"             "URL"
Add-Col "cwf_training" "Description"          "cwf_tr_description"     "Note"
Add-Col "cwf_training" "Active"               "cwf_tr_active"          "Boolean"
$inv += [PSCustomObject]@{list="cwf_training";columns=11;description="Training course catalog"}

# ══════════════════════════════════════════════════════════════
# LIST 7: cwf_personnel_training
# ══════════════════════════════════════════════════════════════
New-List "cwf_personnel_training" "Training completion per person"
Add-Col "cwf_personnel_training" "Personnel Name"     "cwf_pt_personnel_name" "Text"    $true
Add-Col "cwf_personnel_training" "Personnel DoD ID"   "cwf_pt_dod_id"         "Text"    $true
Add-Col "cwf_personnel_training" "Course Name"        "cwf_pt_course_name"    "Text"    $true
Add-Col "cwf_personnel_training" "Course Code"        "cwf_pt_course_code"    "Text"
Add-Col "cwf_personnel_training" "Training Status"    "cwf_pt_status"         "Choice"  $true  $ch_training_status
Add-Col "cwf_personnel_training" "Start Date"         "cwf_pt_start_date"     "DateTime"
Add-Col "cwf_personnel_training" "Completion Date"    "cwf_pt_comp_date"      "DateTime"
Add-Col "cwf_personnel_training" "Expiration Date"    "cwf_pt_exp_date"       "DateTime"
Add-Col "cwf_personnel_training" "Hours Completed"    "cwf_pt_hours"          "Number"
Add-Col "cwf_personnel_training" "Certificate URL"    "cwf_pt_cert_url"       "URL"
Add-Col "cwf_personnel_training" "Notes"              "cwf_pt_notes"          "Note"
$inv += [PSCustomObject]@{list="cwf_personnel_training";columns=11;description="Personnel training records"}

# ══════════════════════════════════════════════════════════════
# LIST 8: cwf_saar
# ══════════════════════════════════════════════════════════════
New-List "cwf_saar" "System Authorization Access Requests (DD 2875)"
Add-Col "cwf_saar" "Requestor Name"               "cwf_saar_requestor"      "Text"    $true
Add-Col "cwf_saar" "Requestor DoD ID"              "cwf_saar_dod_id"         "Text"    $true
Add-Col "cwf_saar" "Requestor Email"               "cwf_saar_email"          "Text"    $true
Add-Col "cwf_saar" "System Name"                   "cwf_saar_system"         "Text"    $true
Add-Col "cwf_saar" "Access Type"                   "cwf_saar_access_type"    "Choice"  $false $ch_access_type
Add-Col "cwf_saar" "Justification"                 "cwf_saar_justification"  "Note"    $true
Add-Col "cwf_saar" "SAAR Workflow Status"           "cwf_saar_wf_status"     "Choice"  $true  $ch_saar_status
Add-Col "cwf_saar" "Supervisor Approval Date"       "cwf_saar_sup_date"      "DateTime"
Add-Col "cwf_saar" "IA Approval Date"               "cwf_saar_ia_date"       "DateTime"
Add-Col "cwf_saar" "Request Date"                   "cwf_saar_request_date"  "DateTime" $true
Add-Col "cwf_saar" "Expiration Date"                "cwf_saar_exp_date"      "DateTime"
Add-Col "cwf_saar" "Cyber Training Complete"        "cwf_saar_cyber_train"   "Boolean"
Add-Col "cwf_saar" "AUP Signed"                     "cwf_saar_aup_signed"    "Boolean"
Add-Col "cwf_saar" "Notes"                           "cwf_saar_notes"        "Note"
$inv += [PSCustomObject]@{list="cwf_saar";columns=14;description="System access requests"}

# ══════════════════════════════════════════════════════════════
# LIST 9: cwf_stig_compliance
# ══════════════════════════════════════════════════════════════
New-List "cwf_stig_compliance" "STIG checklist items and compliance tracking"
Add-Col "cwf_stig_compliance" "STIG ID"            "cwf_stig_id"             "Text"    $true
Add-Col "cwf_stig_compliance" "STIG Title"         "cwf_stig_title"          "Text"    $true
Add-Col "cwf_stig_compliance" "Severity"           "cwf_stig_severity"       "Choice"  $true  $ch_severity
Add-Col "cwf_stig_compliance" "Check Status"       "cwf_stig_check_status"   "Choice"  $true  $ch_check_status
Add-Col "cwf_stig_compliance" "System"             "cwf_stig_system"         "Text"
Add-Col "cwf_stig_compliance" "Rule ID"            "cwf_stig_rule_id"        "Text"
Add-Col "cwf_stig_compliance" "Fix Text"           "cwf_stig_fix_text"       "Note"
Add-Col "cwf_stig_compliance" "Check Text"         "cwf_stig_check_text"     "Note"
Add-Col "cwf_stig_compliance" "Finding Details"    "cwf_stig_finding"        "Note"
Add-Col "cwf_stig_compliance" "Reviewed By"        "cwf_stig_reviewed_by"    "User"
Add-Col "cwf_stig_compliance" "Review Date"        "cwf_stig_review_date"    "DateTime"
Add-Col "cwf_stig_compliance" "POA&M Required"     "cwf_stig_poam_req"       "Boolean"
$inv += [PSCustomObject]@{list="cwf_stig_compliance";columns=12;description="STIG checklist"}

# ══════════════════════════════════════════════════════════════
# LIST 10: cwf_poam
# ══════════════════════════════════════════════════════════════
New-List "cwf_poam" "Plan of Action & Milestones"
Add-Col "cwf_poam" "POAM ID"                "cwf_poam_id"             "Text"    $true
Add-Col "cwf_poam" "Weakness"               "cwf_poam_weakness"       "Note"    $true
Add-Col "cwf_poam" "Related STIG"           "cwf_poam_stig_id"        "Text"
Add-Col "cwf_poam" "Severity"               "cwf_poam_severity"       "Choice"  $false $ch_severity
Add-Col "cwf_poam" "Milestone"              "cwf_poam_milestone"      "Note"
Add-Col "cwf_poam" "Responsible Person"     "cwf_poam_responsible"    "User"
Add-Col "cwf_poam" "Process Status"         "cwf_poam_status"         "Choice"  $true  $ch_process
Add-Col "cwf_poam" "Scheduled Completion"   "cwf_poam_sched_date"     "DateTime" $true
Add-Col "cwf_poam" "Actual Completion"      "cwf_poam_actual_date"    "DateTime"
Add-Col "cwf_poam" "Risk Accepted"          "cwf_poam_risk_accepted"  "Boolean"
Add-Col "cwf_poam" "Notes"                  "cwf_poam_notes"          "Note"
$inv += [PSCustomObject]@{list="cwf_poam";columns=11;description="Plan of Action & Milestones"}

# ══════════════════════════════════════════════════════════════
# LIST 11: cwf_systems
# ══════════════════════════════════════════════════════════════
New-List "cwf_systems" "Information systems inventory"
Add-Col "cwf_systems" "System Name"          "cwf_sys_name"            "Text"    $true
Add-Col "cwf_systems" "System Acronym"       "cwf_sys_acronym"         "Text"
Add-Col "cwf_systems" "eMASS ID"             "cwf_sys_emass_id"        "Text"
Add-Col "cwf_systems" "ATO Status"           "cwf_sys_ato_status"      "Choice"  $false $ch_ato_status
Add-Col "cwf_systems" "ATO Expiration"       "cwf_sys_ato_exp"         "DateTime"
Add-Col "cwf_systems" "ISSM"                 "cwf_sys_issm"            "User"
Add-Col "cwf_systems" "ISSO"                 "cwf_sys_isso"            "User"
Add-Col "cwf_systems" "Classification"       "cwf_sys_classification"  "Choice"  $false $ch_classification
Add-Col "cwf_systems" "Description"          "cwf_sys_description"     "Note"
Add-Col "cwf_systems" "Active"               "cwf_sys_active"          "Boolean"
$inv += [PSCustomObject]@{list="cwf_systems";columns=10;description="Systems inventory"}

# ══════════════════════════════════════════════════════════════
# LIST 12: cwf_waivers
# ══════════════════════════════════════════════════════════════
New-List "cwf_waivers" "Compliance waivers and exceptions"
Add-Col "cwf_waivers" "Waiver ID"            "cwf_waiver_id"           "Text"    $true
Add-Col "cwf_waivers" "Personnel Name"       "cwf_waiver_personnel"    "Text"    $true
Add-Col "cwf_waivers" "Personnel DoD ID"     "cwf_waiver_dod_id"       "Text"
Add-Col "cwf_waivers" "Waiver Type"          "cwf_waiver_type"         "Choice"  $false $ch_waiver_type
Add-Col "cwf_waivers" "Justification"        "cwf_waiver_justification" "Note"   $true
Add-Col "cwf_waivers" "Approval Status"      "cwf_waiver_approval"     "Choice"  $true  $ch_approval
Add-Col "cwf_waivers" "Approving Authority"  "cwf_waiver_authority"    "User"
Add-Col "cwf_waivers" "Request Date"         "cwf_waiver_req_date"     "DateTime" $true
Add-Col "cwf_waivers" "Approval Date"        "cwf_waiver_appr_date"    "DateTime"
Add-Col "cwf_waivers" "Expiration Date"      "cwf_waiver_exp_date"     "DateTime"
Add-Col "cwf_waivers" "Notes"                "cwf_waiver_notes"        "Note"
$inv += [PSCustomObject]@{list="cwf_waivers";columns=11;description="Compliance waivers"}

# ══════════════════════════════════════════════════════════════
# LIST 13: cwf_audit_log
# ══════════════════════════════════════════════════════════════
New-List "cwf_audit_log" "Compliance action audit trail"
Add-Col "cwf_audit_log" "Action"             "cwf_audit_action"        "Choice"  $true  $ch_audit_action
Add-Col "cwf_audit_log" "Entity Type"        "cwf_audit_entity_type"   "Choice"  $false $ch_audit_entity
Add-Col "cwf_audit_log" "Record ID"          "cwf_audit_record_id"     "Text"
Add-Col "cwf_audit_log" "Record Title"       "cwf_audit_record_title"  "Text"
Add-Col "cwf_audit_log" "Performed By"       "cwf_audit_performed_by"  "User"
Add-Col "cwf_audit_log" "Timestamp"          "cwf_audit_timestamp"     "DateTime" $true
Add-Col "cwf_audit_log" "Previous Value"     "cwf_audit_prev_value"    "Note"
Add-Col "cwf_audit_log" "New Value"          "cwf_audit_new_value"     "Note"
Add-Col "cwf_audit_log" "Notes"              "cwf_audit_notes"         "Note"
$inv += [PSCustomObject]@{list="cwf_audit_log";columns=9;description="Audit trail"}

# ══════════════════════════════════════════════════════════════
# LIST 14: cwf_notifications
# ══════════════════════════════════════════════════════════════
New-List "cwf_notifications" "Automated compliance notifications"
Add-Col "cwf_notifications" "Notification Type"  "cwf_notif_type"         "Choice"  $true  $ch_notif_type
Add-Col "cwf_notifications" "Recipient"          "cwf_notif_recipient"    "User"    $true
Add-Col "cwf_notifications" "Recipient Email"    "cwf_notif_email"        "Text"
Add-Col "cwf_notifications" "Subject"            "cwf_notif_subject"      "Text"    $true
Add-Col "cwf_notifications" "Message"            "cwf_notif_message"      "Note"
Add-Col "cwf_notifications" "Related Record"     "cwf_notif_related"      "Text"
Add-Col "cwf_notifications" "Sent Date"          "cwf_notif_sent_date"    "DateTime"
Add-Col "cwf_notifications" "Read"               "cwf_notif_read"         "Boolean"
Add-Col "cwf_notifications" "Priority"           "cwf_notif_priority"     "Choice"  $false $ch_priority
$inv += [PSCustomObject]@{list="cwf_notifications";columns=9;description="Compliance notifications"}

# ══════════════════════════════════════════════════════════════
# LIST 15: cwf_compliance_reports
# ══════════════════════════════════════════════════════════════
New-List "cwf_compliance_reports" "Generated compliance report snapshots"
Add-Col "cwf_compliance_reports" "Report Name"          "cwf_rpt_name"           "Text"    $true
Add-Col "cwf_compliance_reports" "Report Type"          "cwf_rpt_type"           "Choice"  $false $ch_report_type
Add-Col "cwf_compliance_reports" "Generated Date"       "cwf_rpt_gen_date"       "DateTime" $true
Add-Col "cwf_compliance_reports" "Generated By"         "cwf_rpt_gen_by"         "User"
Add-Col "cwf_compliance_reports" "Period Start"         "cwf_rpt_period_start"   "DateTime"
Add-Col "cwf_compliance_reports" "Period End"           "cwf_rpt_period_end"     "DateTime"
Add-Col "cwf_compliance_reports" "Total Personnel"      "cwf_rpt_total"          "Number"
Add-Col "cwf_compliance_reports" "Compliant Count"      "cwf_rpt_compliant"      "Number"
Add-Col "cwf_compliance_reports" "Non-Compliant Count"  "cwf_rpt_non_compliant"  "Number"
Add-Col "cwf_compliance_reports" "Compliance %"         "cwf_rpt_pct"            "Number"
Add-Col "cwf_compliance_reports" "Report URL"           "cwf_rpt_url"            "URL"
Add-Col "cwf_compliance_reports" "Notes"                "cwf_rpt_notes"          "Note"
$inv += [PSCustomObject]@{list="cwf_compliance_reports";columns=12;description="Compliance reports"}

# ══════════════════════════════════════════════════════════════
# LIST 16: cwf_configuration
# ══════════════════════════════════════════════════════════════
New-List "cwf_configuration" "Portal configuration settings"
Add-Col "cwf_configuration" "Setting Name"       "cwf_config_name"        "Text"    $true
Add-Col "cwf_configuration" "Setting Value"      "cwf_config_value"       "Note"    $true
Add-Col "cwf_configuration" "Setting Category"   "cwf_config_category"    "Choice"  $false $ch_config_cat
Add-Col "cwf_configuration" "Description"        "cwf_config_description" "Note"
Add-Col "cwf_configuration" "Data Type"          "cwf_config_data_type"   "Choice"  $false $ch_config_dtype
Add-Col "cwf_configuration" "Last Modified By"   "cwf_config_modified_by" "User"
Add-Col "cwf_configuration" "Last Modified Date" "cwf_config_mod_date"    "DateTime"
$inv += [PSCustomObject]@{list="cwf_configuration";columns=7;description="Portal configuration"}

# ══════════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════════
$totalCols = ($inv | Measure-Object -Property columns -Sum).Sum

Write-Host "`n══════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  LIST PROVISIONING COMPLETE" -ForegroundColor Green
Write-Host "══════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
foreach ($i in $inv) {
    Write-Host "  $($i.list.PadRight(35)) $($i.columns.ToString().PadLeft(3)) cols  $($i.description)" -ForegroundColor White
}
Write-Host "  ─────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host "  Total Lists:   $($inv.Count)" -ForegroundColor Cyan
Write-Host "  Total Columns: $totalCols" -ForegroundColor Cyan
Write-Host "  All columns added to default views" -ForegroundColor Green
Write-Host "  Naming: lowercase_underscore" -ForegroundColor Green
Write-Host ""
$inv | Export-Csv -Path ".\cwf_lists_inventory.csv" -NoTypeInformation
Write-Host "  Inventory: cwf_lists_inventory.csv" -ForegroundColor Gray
Write-Host ""
