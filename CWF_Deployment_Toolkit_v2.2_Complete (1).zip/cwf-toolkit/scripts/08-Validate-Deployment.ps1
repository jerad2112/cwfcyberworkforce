<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 8: Validate Deployment
.DESCRIPTION
    Runs comprehensive checks against the deployed environment:
    - Verifies all Azure AD groups exist and nesting is correct
    - Verifies all SharePoint sites exist and are Hub-associated
    - Verifies all lists exist on correct sites with expected columns
    - Verifies column indexing
    - Verifies permission assignments
    - Generates a validation report (HTML + CSV)
.NOTES
    Requires: PnP.PowerShell, AzureAD or Microsoft.Graph
    Run AFTER all deployment scripts
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [string]$ReportOutputPath,  # Default: same folder as config
    [switch]$UseGraphAPI
)

$ErrorActionPreference = "Continue"  # Don't stop on individual check failures

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$sitePrefix = $config.SharePoint.SitePrefix
$prefix = $config.AzureAD.GroupPrefix
$hubUrl = $config.MSC.HubSiteUrl
$mscName = $config.MSC.Name

if (-not $ReportOutputPath) {
    $ReportOutputPath = Split-Path $ConfigPath
}

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - Deployment Validation" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

$results = @()
$passCount = 0
$failCount = 0
$warnCount = 0

function Add-CheckResult {
    param(
        [string]$Category,
        [string]$Check,
        [string]$Status,  # PASS, FAIL, WARN
        [string]$Details = ""
    )
    
    $icon = switch ($Status) {
        "PASS" { "✓"; $script:passCount++ }
        "FAIL" { "✗"; $script:failCount++ }
        "WARN" { "⚠"; $script:warnCount++ }
    }
    $color = switch ($Status) {
        "PASS" { "Green" }
        "FAIL" { "Red" }
        "WARN" { "Yellow" }
    }
    
    Write-Host "  [$icon] $Check" -ForegroundColor $color -NoNewline
    if ($Details) { Write-Host " - $Details" -ForegroundColor DarkGray } else { Write-Host "" }
    
    $script:results += [PSCustomObject]@{
        Category = $Category
        Check    = $Check
        Status   = $Status
        Details  = $Details
    }
}

# ═══════════════════════════════════════
# CHECK 1: Azure AD Groups
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  CHECK 1: Azure AD Security Groups      │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

if ($UseGraphAPI) {
    Connect-MgGraph -Scopes "Group.Read.All" -ErrorAction SilentlyContinue
} else {
    Connect-AzureAD -ErrorAction SilentlyContinue
}

# Check HQ groups
$hqGroupNames = @("$prefix-ADMIN", "$prefix-ISSM", "$prefix-ANALYST", "$prefix-AUDITOR", "$prefix-SVC", "$prefix-HQALL")
foreach ($grpName in $hqGroupNames) {
    try {
        if ($UseGraphAPI) {
            $grp = Get-MgGroup -Filter "displayName eq '$grpName'" -ErrorAction Stop
        } else {
            $grp = Get-AzureADGroup -Filter "displayName eq '$grpName'" -ErrorAction Stop
        }
        
        if ($grp) {
            Add-CheckResult -Category "AzureAD" -Check "HQ Group: $grpName" -Status "PASS"
        } else {
            Add-CheckResult -Category "AzureAD" -Check "HQ Group: $grpName" -Status "FAIL" -Details "Group not found"
        }
    } catch {
        Add-CheckResult -Category "AzureAD" -Check "HQ Group: $grpName" -Status "FAIL" -Details $_.Exception.Message
    }
}

# Check installation G-6 groups
foreach ($install in $config.Installations) {
    $g6GroupName = "$prefix-$($install.Code)-G6"
    try {
        if ($UseGraphAPI) {
            $grp = Get-MgGroup -Filter "displayName eq '$g6GroupName'"
        } else {
            $grp = Get-AzureADGroup -Filter "displayName eq '$g6GroupName'"
        }
        
        if ($grp) {
            Add-CheckResult -Category "AzureAD" -Check "Install G-6 Group: $g6GroupName" -Status "PASS"
        } else {
            Add-CheckResult -Category "AzureAD" -Check "Install G-6 Group: $g6GroupName" -Status "FAIL" -Details "Group not found"
        }
    } catch {
        Add-CheckResult -Category "AzureAD" -Check "Install G-6 Group: $g6GroupName" -Status "FAIL" -Details $_.Exception.Message
    }
}

# Check ALLINSTG6 nested group
$allInstG6Name = $config.AzureAD.NestedAllInstG6.Name
try {
    if ($UseGraphAPI) {
        $grp = Get-MgGroup -Filter "displayName eq '$allInstG6Name'"
    } else {
        $grp = Get-AzureADGroup -Filter "displayName eq '$allInstG6Name'"
    }
    if ($grp) {
        Add-CheckResult -Category "AzureAD" -Check "Nested Group: $allInstG6Name" -Status "PASS"
    } else {
        Add-CheckResult -Category "AzureAD" -Check "Nested Group: $allInstG6Name" -Status "FAIL" -Details "Group not found"
    }
} catch {
    Add-CheckResult -Category "AzureAD" -Check "Nested Group: $allInstG6Name" -Status "FAIL" -Details $_.Exception.Message
}

# Spot-check directorate groups
$sampleInstall = $config.Installations[0]
$sampleDir = $sampleInstall.Directorates | Where-Object { -not $_.IsHQAdmin -and -not $_.IsInstallG6 } | Select-Object -First 1
if ($sampleDir) {
    foreach ($role in @("Coord", "Supv", "Personnel")) {
        $dirGroupName = "$prefix-$($sampleInstall.Code)-$($sampleDir.Code)-$role"
        try {
            if ($UseGraphAPI) {
                $grp = Get-MgGroup -Filter "displayName eq '$dirGroupName'"
            } else {
                $grp = Get-AzureADGroup -Filter "displayName eq '$dirGroupName'"
            }
            if ($grp) {
                Add-CheckResult -Category "AzureAD" -Check "Sample Dir Group: $dirGroupName" -Status "PASS"
            } else {
                Add-CheckResult -Category "AzureAD" -Check "Sample Dir Group: $dirGroupName" -Status "FAIL" -Details "Group not found"
            }
        } catch {
            Add-CheckResult -Category "AzureAD" -Check "Sample Dir Group: $dirGroupName" -Status "FAIL" -Details $_.Exception.Message
        }
    }
}

# ═══════════════════════════════════════
# CHECK 2: SharePoint Sites
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  CHECK 2: SharePoint Sites              │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

$adminUrl = $config.MSC.AdminSiteUrl
Connect-PnPOnline -Url $adminUrl -Interactive -ErrorAction SilentlyContinue

# Check Hub site
try {
    $hubSite = Get-PnPTenantSite -Url $hubUrl -ErrorAction Stop
    Add-CheckResult -Category "SharePoint" -Check "MSC Hub Site: $hubUrl" -Status "PASS"
    
    # Check if registered as Hub
    $hubInfo = Get-PnPHubSite -Identity $hubUrl -ErrorAction SilentlyContinue
    if ($hubInfo) {
        Add-CheckResult -Category "SharePoint" -Check "MSC Hub Registration" -Status "PASS"
    } else {
        Add-CheckResult -Category "SharePoint" -Check "MSC Hub Registration" -Status "FAIL" -Details "Not registered as Hub Site"
    }
} catch {
    Add-CheckResult -Category "SharePoint" -Check "MSC Hub Site: $hubUrl" -Status "FAIL" -Details $_.Exception.Message
}

# Check all installation and directorate sites
foreach ($install in $config.Installations) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    
    try {
        $site = Get-PnPTenantSite -Url $installUrl -ErrorAction Stop
        Add-CheckResult -Category "SharePoint" -Check "Install Site: $sitePrefix-$($install.Code)" -Status "PASS"
    } catch {
        Add-CheckResult -Category "SharePoint" -Check "Install Site: $sitePrefix-$($install.Code)" -Status "FAIL" -Details "Site not found"
    }
    
    foreach ($dir in $install.Directorates) {
        $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
        try {
            $site = Get-PnPTenantSite -Url $dirUrl -ErrorAction Stop
            Add-CheckResult -Category "SharePoint" -Check "Dir Site: $sitePrefix-$($install.Code)-$($dir.Code)" -Status "PASS"
        } catch {
            Add-CheckResult -Category "SharePoint" -Check "Dir Site: $sitePrefix-$($install.Code)-$($dir.Code)" -Status "FAIL" -Details "Site not found"
        }
    }
}

# ═══════════════════════════════════════
# CHECK 3: List Schemas
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  CHECK 3: List Schemas                  │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

# Check Hub lists
$hubLists = @("CWF_ComplianceStatus", "CWF_EnforcementActions", "CWF_ComplianceWaivers", 
              "CWF_WorkRoles", "CWF_Certifications", "CWF_Organizations", "SyncErrorLog")

Connect-PnPOnline -Url $hubUrl -Interactive -ErrorAction SilentlyContinue
foreach ($listName in $hubLists) {
    $list = Get-PnPList -Identity $listName -ErrorAction SilentlyContinue
    if ($list) {
        Add-CheckResult -Category "Lists" -Check "Hub List: $listName" -Status "PASS" -Details "Items: $($list.ItemCount)"
    } else {
        Add-CheckResult -Category "Lists" -Check "Hub List: $listName" -Status "FAIL" -Details "List not found on Hub"
    }
}

# Check Install Hub lists
$installLists = @("CWF_ComplianceStatus", "CWF_ComplianceFlags", "CWF_WaiverRequests",
                  "CWF_EnforcementActions", "CWF_ComplianceWaivers")

foreach ($install in $config.Installations | Select-Object -First 2) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    Connect-PnPOnline -Url $installUrl -Interactive -ErrorAction SilentlyContinue
    
    foreach ($listName in $installLists) {
        $list = Get-PnPList -Identity $listName -ErrorAction SilentlyContinue
        if ($list) {
            Add-CheckResult -Category "Lists" -Check "Install ($($install.Code)) List: $listName" -Status "PASS"
        } else {
            Add-CheckResult -Category "Lists" -Check "Install ($($install.Code)) List: $listName" -Status "FAIL" -Details "Not found"
        }
    }
}

# Check Directorate lists (sample first directorate of first installation)
$dirLists = @("CWF_Personnel", "CWF_MyCertifications", "CWF_TrainingRecords", 
              "CWF_SAARRequests", "CWF_MyWorkRoles", "CWF_ComplianceStatus", "CWF_Documents")

$sampleInstall = $config.Installations[0]
$sampleDir = $sampleInstall.Directorates[0]
$sampleDirUrl = "https://$tenantDomain/sites/$sitePrefix-$($sampleInstall.Code)-$($sampleDir.Code)"

Connect-PnPOnline -Url $sampleDirUrl -Interactive -ErrorAction SilentlyContinue
foreach ($listName in $dirLists) {
    $list = Get-PnPList -Identity $listName -ErrorAction SilentlyContinue
    if ($list) {
        Add-CheckResult -Category "Lists" -Check "Dir ($($sampleInstall.Code)-$($sampleDir.Code)) List: $listName" -Status "PASS"
    } else {
        Add-CheckResult -Category "Lists" -Check "Dir ($($sampleInstall.Code)-$($sampleDir.Code)) List: $listName" -Status "FAIL" -Details "Not found"
    }
}

# Check critical columns on CWF_Personnel
$criticalColumns = @("FirstName", "DoDID", "PersonnelEmail", "DV_RecordID", "DV_SyncStatus", "DV_OrgUIC", "G6Notes")
$personnelList = Get-PnPList -Identity "CWF_Personnel" -ErrorAction SilentlyContinue
if ($personnelList) {
    foreach ($colName in $criticalColumns) {
        $col = Get-PnPField -List "CWF_Personnel" -Identity $colName -ErrorAction SilentlyContinue
        if ($col) {
            Add-CheckResult -Category "Columns" -Check "CWF_Personnel.$colName" -Status "PASS" -Details "Type: $($col.TypeAsString)"
        } else {
            Add-CheckResult -Category "Columns" -Check "CWF_Personnel.$colName" -Status "FAIL" -Details "Column not found"
        }
    }
}

# Check indexed columns
$indexChecks = @(
    @{ List="CWF_Personnel"; Column="DV_OrgUIC" }
    @{ List="CWF_Personnel"; Column="DoDID" }
    @{ List="CWF_Personnel"; Column="DV_SyncStatus" }
)
foreach ($ic in $indexChecks) {
    $field = Get-PnPField -List $ic.List -Identity $ic.Column -ErrorAction SilentlyContinue
    if ($field -and $field.Indexed) {
        Add-CheckResult -Category "Indexing" -Check "$($ic.List).$($ic.Column) indexed" -Status "PASS"
    } elseif ($field) {
        Add-CheckResult -Category "Indexing" -Check "$($ic.List).$($ic.Column) indexed" -Status "WARN" -Details "Column exists but not indexed"
    } else {
        Add-CheckResult -Category "Indexing" -Check "$($ic.List).$($ic.Column) indexed" -Status "FAIL" -Details "Column not found"
    }
}

# Check views
$viewChecks = @(
    @{ List="CWF_Personnel"; View="My Records" }
    @{ List="CWF_Personnel"; View="All Personnel" }
    @{ List="CWF_SAARRequests"; View="Pending Approval" }
    @{ List="CWF_ComplianceStatus"; View="Non-Compliant" }
)
foreach ($vc in $viewChecks) {
    $view = Get-PnPView -List $vc.List -Identity $vc.View -ErrorAction SilentlyContinue
    if ($view) {
        Add-CheckResult -Category "Views" -Check "$($vc.List) / $($vc.View)" -Status "PASS"
    } else {
        Add-CheckResult -Category "Views" -Check "$($vc.List) / $($vc.View)" -Status "FAIL" -Details "View not found"
    }
}

# ═══════════════════════════════════════
# GENERATE REPORT
# ═══════════════════════════════════════
Write-Host "`n═══════════════════════════════════════════" -ForegroundColor $(if ($failCount -eq 0) { "Green" } else { "Red" })
Write-Host "  VALIDATION SUMMARY" -ForegroundColor $(if ($failCount -eq 0) { "Green" } else { "Red" })
Write-Host "═══════════════════════════════════════════" -ForegroundColor $(if ($failCount -eq 0) { "Green" } else { "Red" })
Write-Host ""
Write-Host "  PASSED:   $passCount" -ForegroundColor Green
Write-Host "  FAILED:   $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Gray" })
Write-Host "  WARNINGS: $warnCount" -ForegroundColor $(if ($warnCount -gt 0) { "Yellow" } else { "Gray" })
Write-Host "  ─────────────────" -ForegroundColor Gray
Write-Host "  TOTAL:    $($results.Count)" -ForegroundColor Cyan
Write-Host ""

if ($failCount -eq 0) {
    Write-Host "  ✓ ALL CHECKS PASSED - Deployment is valid" -ForegroundColor Green
} else {
    Write-Host "  ✗ $failCount CHECK(S) FAILED - Review failures above and re-run affected scripts" -ForegroundColor Red
}

# Export CSV report
$csvPath = Join-Path $ReportOutputPath "cwf-validation-report.csv"
$results | Export-Csv -Path $csvPath -NoTypeInformation
Write-Host "`n  Report exported to: $csvPath" -ForegroundColor Gray

# Export HTML report
$htmlPath = Join-Path $ReportOutputPath "cwf-validation-report.html"
$htmlContent = @"
<!DOCTYPE html>
<html><head>
<title>CWF Deployment Validation Report</title>
<style>
body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background: #faf9f8; }
h1 { color: #1F4E79; }
.summary { display: flex; gap: 20px; margin: 20px 0; }
.metric { padding: 16px 24px; border-radius: 8px; font-size: 24px; font-weight: 700; }
.pass { background: #dff6dd; color: #107c10; }
.fail { background: #fde7e9; color: #a4262c; }
.warn { background: #fff4ce; color: #8a6914; }
table { width: 100%; border-collapse: collapse; background: white; border: 1px solid #edebe9; }
th { background: #1F4E79; color: white; padding: 10px 14px; text-align: left; font-size: 13px; }
td { padding: 8px 14px; border-bottom: 1px solid #f3f2f1; font-size: 13px; }
tr:nth-child(even) { background: #faf9f8; }
.status-pass { color: #107c10; font-weight: 700; }
.status-fail { color: #a4262c; font-weight: 700; }
.status-warn { color: #8a6914; font-weight: 700; }
</style></head><body>
<h1>CWF Deployment Validation Report</h1>
<p>MSC: <strong>$mscName</strong> | Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm') | Config: $ConfigPath</p>
<div class='summary'>
<div class='metric pass'>$passCount PASSED</div>
<div class='metric fail'>$failCount FAILED</div>
<div class='metric warn'>$warnCount WARNINGS</div>
</div>
<table>
<tr><th>Category</th><th>Check</th><th>Status</th><th>Details</th></tr>
"@

foreach ($r in $results) {
    $statusClass = "status-$($r.Status.ToLower())"
    $htmlContent += "<tr><td>$($r.Category)</td><td>$($r.Check)</td><td class='$statusClass'>$($r.Status)</td><td>$($r.Details)</td></tr>`n"
}

$htmlContent += "</table></body></html>"
$htmlContent | Out-File -FilePath $htmlPath -Encoding UTF8

Write-Host "  HTML report: $htmlPath" -ForegroundColor Gray
Write-Host ""
