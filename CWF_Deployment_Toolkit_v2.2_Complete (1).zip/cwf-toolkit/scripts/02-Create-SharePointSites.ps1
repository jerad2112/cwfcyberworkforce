<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 2: Create SharePoint Sites
.DESCRIPTION
    Creates the full SharePoint site topology:
    - MSC Hub site (registered as Hub)
    - Installation Hub sites (associated to MSC Hub)
    - Directorate consumer sites (associated to MSC Hub)
    All sites use Communication Site template for modern pages.
.NOTES
    Requires: PnP.PowerShell module (Install-Module PnP.PowerShell)
    Run as: SharePoint Admin
    Environment: GCC / GCC High
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$adminUrl = $config.MSC.AdminSiteUrl
$sitePrefix = $config.SharePoint.SitePrefix
$template = $config.SharePoint.SiteTemplate
$mscName = $config.MSC.Name
$hubUrl = $config.MSC.HubSiteUrl

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - SharePoint Site Provisioning" -ForegroundColor Cyan  
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

# ── Connect to SharePoint Admin ──
Write-Host "Connecting to SharePoint Admin: $adminUrl" -ForegroundColor Gray
Connect-PnPOnline -Url $adminUrl -Interactive

# ── Helper Functions ──
function New-CWFSite {
    param(
        [string]$SiteUrl,
        [string]$Title,
        [string]$Description,
        [string]$OwnerEmail,
        [string]$SiteLevel  # "MSCHub", "InstallHub", "Directorate"
    )
    
    Write-Host "  Creating: $Title" -ForegroundColor White -NoNewline
    Write-Host " ($SiteUrl)" -ForegroundColor Gray
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create site" -ForegroundColor DarkYellow
        return
    }
    
    # Check if site already exists
    $existing = $null
    try {
        $existing = Get-PnPTenantSite -Url $SiteUrl -ErrorAction SilentlyContinue
    } catch {}
    
    if ($existing) {
        Write-Host "    [EXISTS] Site already exists - skipping creation" -ForegroundColor DarkYellow
        return
    }
    
    # Create Communication Site
    New-PnPSite -Type CommunicationSite `
        -Title $Title `
        -Url $SiteUrl `
        -Description $Description `
        -Owner $OwnerEmail `
        -Wait
    
    Write-Host "    [CREATED]" -ForegroundColor Green
    
    # Apply theme color
    Start-Sleep -Seconds 5  # Wait for site provisioning
}

function Register-CWFHub {
    param(
        [string]$SiteUrl,
        [string]$Title
    )
    
    Write-Host "  Registering as Hub: $Title" -ForegroundColor Yellow
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would register as hub" -ForegroundColor DarkYellow
        return
    }
    
    try {
        Register-PnPHubSite -Site $SiteUrl
        Write-Host "    [REGISTERED]" -ForegroundColor Green
    } catch {
        if ($_.Exception.Message -match "already a HubSite") {
            Write-Host "    [ALREADY HUB]" -ForegroundColor DarkYellow
        } else { throw }
    }
}

function Add-CWFHubAssociation {
    param(
        [string]$SiteUrl,
        [string]$HubSiteUrl
    )
    
    Write-Host "  Associating to Hub: $SiteUrl --> $HubSiteUrl" -ForegroundColor Gray
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would associate" -ForegroundColor DarkYellow
        return
    }
    
    try {
        Add-PnPHubSiteAssociation -Site $SiteUrl -HubSite $HubSiteUrl
        Write-Host "    [ASSOCIATED]" -ForegroundColor Green
    } catch {
        if ($_.Exception.Message -match "already associated") {
            Write-Host "    [ALREADY ASSOCIATED]" -ForegroundColor DarkYellow
        } else { throw }
    }
}

# Track all created sites for output
$siteInventory = @()
$ownerEmail = $config.ServiceAccount.UPN

# ═══════════════════════════════════════
# PHASE 1: MSC Hub Site
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 1: MSC Hub Site                  │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

New-CWFSite -SiteUrl $hubUrl `
    -Title "$mscName CWF Compliance Portal" `
    -Description $config.SharePoint.HubDescription `
    -OwnerEmail $ownerEmail `
    -SiteLevel "MSCHub"

Register-CWFHub -SiteUrl $hubUrl -Title "$mscName CWF Hub"

$siteInventory += [PSCustomObject]@{
    SiteCode = "$sitePrefix-HUB"
    Url = $hubUrl
    Level = "L2-MSCHub"
    Installation = ""
    Directorate = ""
    IsHub = $true
}

# ═══════════════════════════════════════
# PHASE 2: Installation Hub Sites
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 2: Installation Hub Sites        │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

foreach ($install in $config.Installations) {
    $installSiteUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    
    New-CWFSite -SiteUrl $installSiteUrl `
        -Title "$mscName CWF - $($install.Name)" `
        -Description "CWF Compliance Portal - $($install.Name) Installation Hub" `
        -OwnerEmail $ownerEmail `
        -SiteLevel "InstallHub"
    
    Add-CWFHubAssociation -SiteUrl $installSiteUrl -HubSiteUrl $hubUrl
    
    $siteInventory += [PSCustomObject]@{
        SiteCode = "$sitePrefix-$($install.Code)"
        Url = $installSiteUrl
        Level = "L3-InstallHub"
        Installation = $install.Code
        Directorate = ""
        IsHub = $false
    }
}

# ═══════════════════════════════════════
# PHASE 3: Directorate Consumer Sites
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 3: Directorate Sites             │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

foreach ($install in $config.Installations) {
    Write-Host "`n  Installation: $($install.Name)" -ForegroundColor Yellow
    
    foreach ($dir in $install.Directorates) {
        $dirSiteUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
        
        New-CWFSite -SiteUrl $dirSiteUrl `
            -Title "$mscName CWF - $($install.Name) $($dir.Name)" `
            -Description "CWF Compliance Portal - $($dir.Name) at $($install.Name)" `
            -OwnerEmail $ownerEmail `
            -SiteLevel "Directorate"
        
        Add-CWFHubAssociation -SiteUrl $dirSiteUrl -HubSiteUrl $hubUrl
        
        $siteInventory += [PSCustomObject]@{
            SiteCode = "$sitePrefix-$($install.Code)-$($dir.Code)"
            Url = $dirSiteUrl
            Level = "L4-Directorate"
            Installation = $install.Code
            Directorate = $dir.Code
            IsHub = $false
        }
    }
}

# ═══════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════
$hubCount = ($siteInventory | Where-Object { $_.Level -eq "L2-MSCHub" }).Count
$installCount = ($siteInventory | Where-Object { $_.Level -eq "L3-InstallHub" }).Count
$dirCount = ($siteInventory | Where-Object { $_.Level -eq "L4-Directorate" }).Count

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  SITE PROVISIONING COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  MSC Hub Sites:          $hubCount" -ForegroundColor White
Write-Host "  Installation Hub Sites: $installCount" -ForegroundColor White
Write-Host "  Directorate Sites:      $dirCount" -ForegroundColor White
Write-Host "  ─────────────────────────────" -ForegroundColor Gray
Write-Host "  Total Sites Created:    $($siteInventory.Count)" -ForegroundColor Cyan
Write-Host ""

# Export site inventory
$exportPath = Join-Path (Split-Path $ConfigPath) "sharepoint-sites-inventory.csv"
$siteInventory | Export-Csv -Path $exportPath -NoTypeInformation
Write-Host "  Site inventory exported to: $exportPath" -ForegroundColor Gray
Write-Host ""
