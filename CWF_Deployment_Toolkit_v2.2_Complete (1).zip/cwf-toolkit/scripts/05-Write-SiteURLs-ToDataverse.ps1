<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 5: Write Site URLs to Dataverse
.DESCRIPTION
    Updates cwf_SPSiteURL and cwf_SPInstallHubURL on each Dataverse 
    cwf_Organization record so Power Automate flows can route sync 
    operations to the correct SharePoint site.
.NOTES
    Requires: Microsoft.Xrm.Data.Powershell or pac CLI
    Run AFTER: 02-Create-SharePointSites.ps1
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [Parameter(Mandatory=$true)]
    [string]$DataverseUrl,  # e.g., https://org-tacom.crm9.dynamics.com
    
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$sitePrefix = $config.SharePoint.SitePrefix
$hubUrl = $config.MSC.HubSiteUrl

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - Dataverse URL Writeback" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

# Connect to Dataverse
Write-Host "Connecting to Dataverse: $DataverseUrl" -ForegroundColor Gray
Connect-CrmOnline -ServerUrl $DataverseUrl

# Build URL mapping from config
$urlMap = @()

# MSC Hub
$urlMap += [PSCustomObject]@{ UIC=$config.MSC.UIC; SPSiteURL=$hubUrl; SPInstallHubURL=$hubUrl; Name="$($config.MSC.Name) Hub" }

# Installations
foreach ($install in $config.Installations) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    $urlMap += [PSCustomObject]@{ UIC=$install.UIC; SPSiteURL=$installUrl; SPInstallHubURL=$installUrl; Name=$install.Name }
    
    # Directorates
    foreach ($dir in $install.Directorates) {
        $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
        $urlMap += [PSCustomObject]@{ UIC=$dir.UIC; SPSiteURL=$dirUrl; SPInstallHubURL=$installUrl; Name=$dir.Name }
    }
}

Write-Host "  URL mappings to write: $($urlMap.Count)" -ForegroundColor Yellow
Write-Host ""

foreach ($mapping in $urlMap) {
    Write-Host "  $($mapping.UIC): $($mapping.Name)" -ForegroundColor White -NoNewline
    Write-Host " -> $($mapping.SPSiteURL)" -ForegroundColor Gray
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would update Dataverse record" -ForegroundColor DarkYellow
        continue
    }
    
    try {
        # Query for the org record by UIC
        $record = Get-CrmRecords -EntityLogicalName "cwf_organization" `
            -FilterAttribute "cwf_uic" -FilterOperator "eq" -FilterValue $mapping.UIC `
            -Fields "cwf_organizationid","cwf_uic","cwf_name"
        
        if ($record.Count -gt 0) {
            $orgId = $record.CrmRecords[0].cwf_organizationid
            
            Set-CrmRecord -EntityLogicalName "cwf_organization" `
                -Id $orgId `
                -Fields @{
                    "cwf_spsiteurl" = $mapping.SPSiteURL
                    "cwf_spinstallhuburl" = $mapping.SPInstallHubURL
                }
            
            Write-Host "    [UPDATED] $orgId" -ForegroundColor Green
        } else {
            Write-Host "    [NOT FOUND] No DV record for UIC $($mapping.UIC)" -ForegroundColor Red
        }
    } catch {
        Write-Host "    [ERROR] $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  URL WRITEBACK COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Green
