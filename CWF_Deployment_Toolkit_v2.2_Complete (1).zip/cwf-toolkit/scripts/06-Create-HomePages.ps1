<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 6: Create SharePoint Home Pages
.DESCRIPTION
    Creates preconfigured home pages for each site type:
    - MSC Hub: Compliance dashboard, install navigation, Canvas App link (audience targeted), reference data links
    - Installation Hub: Install dashboard, compliance flags queue, directorate navigation, HQ escalation links
    - Directorate Site: Quick actions, my compliance card, recent activity, reference links
.NOTES
    Requires: PnP.PowerShell module
    Run AFTER: 03-Deploy-ListSchemas.ps1
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [ValidateSet("All", "MSCHub", "InstallHubs", "Directorates")]
    [string]$Target = "All",
    
    [string]$CanvasAppId = "",  # Power Apps App ID for embedding
    
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$sitePrefix = $config.SharePoint.SitePrefix
$hubUrl = $config.MSC.HubSiteUrl
$mscName = $config.MSC.Name

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - SharePoint Page Creation" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

# ── Helper: Add a modern page with sections and web parts ──
function New-CWFPage {
    param(
        [string]$SiteUrl,
        [string]$PageName,
        [string]$PageTitle,
        [scriptblock]$ContentBuilder
    )
    
    Write-Host "  Page: $PageTitle ($PageName)" -ForegroundColor White
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create page" -ForegroundColor DarkYellow
        return
    }
    
    Connect-PnPOnline -Url $SiteUrl -Interactive
    
    # Check if page exists
    $existing = Get-PnPPage -Identity $PageName -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "    [EXISTS] Page already exists - removing to recreate" -ForegroundColor DarkYellow
        Remove-PnPPage -Identity $PageName -Force
    }
    
    # Create page
    $page = Add-PnPPage -Name $PageName -LayoutType Home -CommentsEnabled:$false
    Set-PnPPage -Identity $PageName -Title $PageTitle
    
    # Execute content builder
    & $ContentBuilder $PageName
    
    # Publish
    Set-PnPPage -Identity $PageName -Publish
    
    # Set as home page
    Set-PnPHomePage -RootFolderRelativeUrl "SitePages/$PageName.aspx"
    
    Write-Host "    [CREATED] Set as home page" -ForegroundColor Green
}

# ═══════════════════════════════════════
# MSC HUB HOME PAGE
# ═══════════════════════════════════════
if ($Target -eq "All" -or $Target -eq "MSCHub") {
    Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│  MSC Hub Home Page                      │" -ForegroundColor Cyan
    Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan
    
    New-CWFPage -SiteUrl $hubUrl -PageName "Home" -PageTitle "$mscName CWF Compliance Portal" -ContentBuilder {
        param($pageName)
        
        # Section 1: Hero Banner
        Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 1
        Add-PnPPageTextPart -Page $pageName -Section 1 -Column 1 -Text @"
<h1 style='color:#1F4E79'>$mscName Cyber Workforce Compliance Portal</h1>
<p style='font-size:16px;color:#595959'>Centralized DoD 8140 compliance management across all $mscName installations. 
This portal is managed by $mscName G-6 Cyber &amp; Operations.</p>
<hr style='border:2px solid #1F4E79'/>
"@
        
        # Section 2: Compliance Status Rollup (two columns)
        Add-PnPPageSection -Page $pageName -SectionTemplate TwoColumn -Order 2
        
        # Left: Compliance Status list web part
        Add-PnPPageWebPart -Page $pageName -Section 2 -Column 1 -DefaultWebPartType List -WebPartProperties @{
            "selectedListId" = (Get-PnPList -Identity "CWF_ComplianceStatus").Id.ToString()
            "selectedViewId" = (Get-PnPView -List "CWF_ComplianceStatus" -Identity "Org Compliance" -ErrorAction SilentlyContinue).Id.ToString()
        }
        
        # Right: Quick stats text
        Add-PnPPageTextPart -Page $pageName -Section 2 -Column 2 -Text @"
<h2 style='color:#2E75B6'>Installation Navigation</h2>
<ul style='font-size:14px;line-height:2'>
$(foreach ($install in $config.Installations) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    "<li><a href='$installUrl'>$($install.Name)</a></li>"
})
</ul>
"@
        
        # Section 3: Reference Data Links
        Add-PnPPageSection -Page $pageName -SectionTemplate ThreeColumn -Order 3
        
        Add-PnPPageTextPart -Page $pageName -Section 3 -Column 1 -Text @"
<h3 style='color:#2E75B6'>&#128214; Reference Data</h3>
<ul>
<li><a href='$hubUrl/Lists/CWF_WorkRoles'>DCWF Work Role Catalog</a></li>
<li><a href='$hubUrl/Lists/CWF_Certifications'>Certification Catalog</a></li>
<li><a href='$hubUrl/Lists/CWF_Organizations'>Organization Hierarchy</a></li>
</ul>
"@
        
        Add-PnPPageTextPart -Page $pageName -Section 3 -Column 2 -Text @"
<h3 style='color:#2E75B6'>&#9881; Administration</h3>
<ul>
<li><a href='$hubUrl/Lists/SyncErrorLog'>Sync Error Log</a></li>
<li><a href='$hubUrl/Lists/CWF_EnforcementActions'>Enforcement Actions</a></li>
<li><a href='$hubUrl/Lists/CWF_ComplianceWaivers'>Active Waivers</a></li>
</ul>
"@
        
        Add-PnPPageTextPart -Page $pageName -Section 3 -Column 3 -Text @"
<h3 style='color:#2E75B6'>&#128203; Resources</h3>
<ul>
<li><a href='https://public.cyber.mil/cw/dcwf/'>DoD DCWF Reference</a></li>
<li><a href='#'>CWF Policy Documents</a></li>
<li><a href='#'>Build Guide v2.2</a></li>
</ul>
"@
        
        # Section 4: Canvas App Link (audience targeted to HQALL - manual step note)
        Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 4
        
        if ($CanvasAppId) {
            Add-PnPPageTextPart -Page $pageName -Section 4 -Column 1 -Text @"
<div style='background:#E8F0FE;border:2px solid #0078D4;border-radius:8px;padding:20px;margin-top:20px'>
<h2 style='color:#0078D4;margin-top:0'>&#128736; G-6 Compliance Workstation</h2>
<p>Access the Canvas App for compliance decisions, SAAR approvals, enforcement actions, and reporting.</p>
<p><a href='https://apps.powerapps.com/play/e/$($config.MSC.DataverseEnvironmentUrl.Split('/')[2].Split('.')[0])/a/$CanvasAppId' 
   style='background:#0078D4;color:white;padding:10px 24px;border-radius:4px;text-decoration:none;font-weight:bold'>
   Launch Compliance Workstation</a></p>
<p style='font-size:12px;color:#888'>This section is audience-targeted to HQ G-6 staff only. 
Configure audience targeting after page creation: Edit page > Select this section > Audience targeting > SG-$($config.AzureAD.GroupPrefix)-HQALL</p>
</div>
"@
        } else {
            Add-PnPPageTextPart -Page $pageName -Section 4 -Column 1 -Text @"
<div style='background:#FFF4CE;border:2px solid #C8AB37;border-radius:8px;padding:20px;margin-top:20px'>
<h3 style='color:#8A6914;margin-top:0'>&#9888; Canvas App Not Configured</h3>
<p>Run this script with <code>-CanvasAppId</code> parameter to embed the G-6 Compliance Workstation link.</p>
<p>After embedding, configure audience targeting on this section to: <strong>SG-$($config.AzureAD.GroupPrefix)-HQALL</strong></p>
</div>
"@
        }
    }
}

# ═══════════════════════════════════════
# INSTALLATION HUB HOME PAGES
# ═══════════════════════════════════════
if ($Target -eq "All" -or $Target -eq "InstallHubs") {
    Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│  Installation Hub Home Pages            │" -ForegroundColor Cyan
    Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan
    
    foreach ($install in $config.Installations) {
        $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
        
        New-CWFPage -SiteUrl $installUrl -PageName "Home" -PageTitle "$($install.Name) - CWF Compliance" -ContentBuilder {
            param($pageName)
            
            # Section 1: Banner
            Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 1
            Add-PnPPageTextPart -Page $pageName -Section 1 -Column 1 -Text @"
<h1 style='color:#1F4E79'>$($install.Name)</h1>
<p style='font-size:16px;color:#595959'>CWF Compliance Dashboard &mdash; Managed by $($install.Name) G-6</p>
<hr style='border:2px solid #1F4E79'/>
"@
            
            # Section 2: Compliance Status + Directorate Nav
            Add-PnPPageSection -Page $pageName -SectionTemplate TwoColumnLeft -Order 2
            
            # Left: Compliance rollup list
            try {
                $compList = Get-PnPList -Identity "CWF_ComplianceStatus" -ErrorAction SilentlyContinue
                if ($compList) {
                    Add-PnPPageWebPart -Page $pageName -Section 2 -Column 1 -DefaultWebPartType List -WebPartProperties @{
                        "selectedListId" = $compList.Id.ToString()
                    }
                }
            } catch {}
            
            # Right: Directorate links
            $dirLinks = ""
            foreach ($dir in $install.Directorates) {
                $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
                $badge = ""
                if ($dir.IsInstallG6 -or $dir.IsHQAdmin) { $badge = " &#128274;" }
                $dirLinks += "<li><a href='$dirUrl'>$($dir.Name)</a>$badge</li>`n"
            }
            
            Add-PnPPageTextPart -Page $pageName -Section 2 -Column 2 -Text @"
<h2 style='color:#2E75B6'>Directorates</h2>
<ul style='font-size:14px;line-height:2'>
$dirLinks
</ul>
<p style='font-size:12px;color:#888'>&#128274; = G-6 compliance authority</p>
"@
            
            # Section 3: G-6 Action Queue (Flags + Waiver Requests)
            Add-PnPPageSection -Page $pageName -SectionTemplate TwoColumn -Order 3
            
            Add-PnPPageTextPart -Page $pageName -Section 3 -Column 1 -Text @"
<h2 style='color:#2E75B6'>&#128680; Compliance Flags</h2>
<p>Issues flagged for HQ review. <a href='$installUrl/Lists/CWF_ComplianceFlags'>View all flags</a></p>
<p><a href='$installUrl/Lists/CWF_ComplianceFlags/NewForm.aspx' 
   style='background:#D83B01;color:white;padding:8px 16px;border-radius:4px;text-decoration:none;font-weight:bold'>
   + New Compliance Flag</a></p>
"@
            
            Add-PnPPageTextPart -Page $pageName -Section 3 -Column 2 -Text @"
<h2 style='color:#2E75B6'>&#128203; Waiver Requests</h2>
<p>Waiver requests submitted to HQ. <a href='$installUrl/Lists/CWF_WaiverRequests'>View all requests</a></p>
<p><a href='$installUrl/Lists/CWF_WaiverRequests/NewForm.aspx'
   style='background:#0078D4;color:white;padding:8px 16px;border-radius:4px;text-decoration:none;font-weight:bold'>
   + New Waiver Request</a></p>
"@
            
            # Section 4: HQ Decisions (read-only)
            Add-PnPPageSection -Page $pageName -SectionTemplate TwoColumn -Order 4
            
            Add-PnPPageTextPart -Page $pageName -Section 4 -Column 1 -Text @"
<h3 style='color:#595959'>&#9888; Active Enforcement Actions</h3>
<p><a href='$installUrl/Lists/CWF_EnforcementActions'>View enforcement actions from HQ</a></p>
<p style='font-size:12px;color:#888'>Read-only &mdash; created by $mscName G-6 HQ</p>
"@
            
            Add-PnPPageTextPart -Page $pageName -Section 4 -Column 2 -Text @"
<h3 style='color:#595959'>&#9989; Active Waivers</h3>
<p><a href='$installUrl/Lists/CWF_ComplianceWaivers'>View active compliance waivers</a></p>
<p style='font-size:12px;color:#888'>Read-only &mdash; granted by $mscName G-6 HQ</p>
"@
            
            # Section 5: Hub link
            Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 5
            Add-PnPPageTextPart -Page $pageName -Section 5 -Column 1 -Text @"
<p style='text-align:center;margin-top:20px'>
<a href='$hubUrl' style='color:#0078D4'>&#8592; Back to $mscName CWF Hub</a> | 
<a href='$hubUrl/Lists/CWF_WorkRoles'>Work Role Catalog</a> | 
<a href='$hubUrl/Lists/CWF_Certifications'>Certification Catalog</a>
</p>
"@
        }
    }
}

# ═══════════════════════════════════════
# DIRECTORATE SITE HOME PAGES
# ═══════════════════════════════════════
if ($Target -eq "All" -or $Target -eq "Directorates") {
    Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│  Directorate Site Home Pages            │" -ForegroundColor Cyan
    Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan
    
    foreach ($install in $config.Installations) {
        $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
        
        foreach ($dir in $install.Directorates) {
            $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
            $isG6 = ($dir.IsHQAdmin -eq $true) -or ($dir.IsInstallG6 -eq $true)
            
            New-CWFPage -SiteUrl $dirUrl -PageName "Home" -PageTitle "$($dir.Name) - CWF Portal" -ContentBuilder {
                param($pageName)
                
                # Section 1: Banner
                Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 1
                
                $g6Badge = ""
                if ($isG6) { $g6Badge = "<span style='background:#107C10;color:white;padding:2px 8px;border-radius:4px;font-size:12px;margin-left:8px'>G-6 Compliance Authority</span>" }
                
                Add-PnPPageTextPart -Page $pageName -Section 1 -Column 1 -Text @"
<h1 style='color:#1F4E79'>$($dir.Name) $g6Badge</h1>
<p style='font-size:16px;color:#595959'>$($install.Name) &mdash; CWF Compliance Portal</p>
<hr style='border:2px solid #1F4E79'/>
"@
                
                # Section 2: Quick Actions
                Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 2
                Add-PnPPageTextPart -Page $pageName -Section 2 -Column 1 -Text @"
<h2 style='color:#2E75B6'>Quick Actions</h2>
<div style='display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px'>
<a href='$dirUrl/Lists/CWF_Personnel/NewForm.aspx' style='background:#0078D4;color:white;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:bold'>&#128100; New Personnel Record</a>
<a href='$dirUrl/Lists/CWF_MyCertifications/NewForm.aspx' style='background:#0078D4;color:white;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:bold'>&#128220; Submit Certification</a>
<a href='$dirUrl/Lists/CWF_TrainingRecords/NewForm.aspx' style='background:#0078D4;color:white;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:bold'>&#128218; Log Training</a>
<a href='$dirUrl/Lists/CWF_SAARRequests/NewForm.aspx' style='background:#0078D4;color:white;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:bold'>&#128203; New SAAR Request</a>
<a href='$dirUrl/CWF_Documents' style='background:#107C10;color:white;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:bold'>&#128193; Upload Document</a>
</div>
"@
                
                # Section 3: My Compliance + Recent Activity
                Add-PnPPageSection -Page $pageName -SectionTemplate TwoColumn -Order 3
                
                # Left: Compliance status
                try {
                    $compList = Get-PnPList -Identity "CWF_ComplianceStatus" -ErrorAction SilentlyContinue
                    if ($compList) {
                        $myView = Get-PnPView -List "CWF_ComplianceStatus" -Identity "My Compliance" -ErrorAction SilentlyContinue
                        if ($myView) {
                            Add-PnPPageWebPart -Page $pageName -Section 3 -Column 1 -DefaultWebPartType List -WebPartProperties @{
                                "selectedListId" = $compList.Id.ToString()
                                "selectedViewId" = $myView.Id.ToString()
                            }
                        }
                    }
                } catch {
                    Add-PnPPageTextPart -Page $pageName -Section 3 -Column 1 -Text @"
<h3 style='color:#2E75B6'>&#9989; My Compliance Status</h3>
<p><a href='$dirUrl/Lists/CWF_ComplianceStatus'>View compliance status</a></p>
<p style='font-size:12px;color:#888'>Read-only &mdash; refreshed daily from compliance engine</p>
"@
                }
                
                # Right: My lists
                Add-PnPPageTextPart -Page $pageName -Section 3 -Column 2 -Text @"
<h3 style='color:#2E75B6'>&#128196; My Records</h3>
<ul style='font-size:14px;line-height:2'>
<li><a href='$dirUrl/Lists/CWF_Personnel'>My Personnel Record</a></li>
<li><a href='$dirUrl/Lists/CWF_MyCertifications'>My Certifications</a></li>
<li><a href='$dirUrl/Lists/CWF_TrainingRecords'>My Training Records</a></li>
<li><a href='$dirUrl/Lists/CWF_SAARRequests'>My SAAR Requests</a></li>
<li><a href='$dirUrl/Lists/CWF_MyWorkRoles'>My Work Roles</a></li>
<li><a href='$dirUrl/CWF_Documents'>My Documents</a></li>
</ul>
"@
                
                # Section 4: Reference links
                Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -Order 4
                Add-PnPPageTextPart -Page $pageName -Section 4 -Column 1 -Text @"
<p style='text-align:center;margin-top:20px;border-top:1px solid #edebe9;padding-top:12px'>
<a href='$installUrl' style='color:#0078D4'>&#8592; $($install.Name) Dashboard</a> | 
<a href='$hubUrl' style='color:#0078D4'>$mscName Hub</a> | 
<a href='$hubUrl/Lists/CWF_WorkRoles'>Work Role Catalog</a> | 
<a href='$hubUrl/Lists/CWF_Certifications'>Cert Catalog</a>
</p>
<p style='text-align:center;font-size:12px;color:#a19f9d'>
Data syncs to Dataverse automatically via Power Automate. Check the Sync Status column on any list for sync state.
</p>
"@
            }
        }
    }
}

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  PAGE CREATION COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  MANUAL STEPS REQUIRED:" -ForegroundColor Yellow
Write-Host "  1. Edit MSC Hub home page > Canvas App section > Configure audience targeting to SG-$($config.AzureAD.GroupPrefix)-HQALL" -ForegroundColor Yellow
Write-Host "  2. Review each page layout and adjust web part sizing as needed" -ForegroundColor Yellow
Write-Host "  3. Add site logo and branding to each Hub site" -ForegroundColor Yellow
Write-Host ""
