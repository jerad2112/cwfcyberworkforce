<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 4: Configure SharePoint Permissions
.DESCRIPTION
    Applies the centralized HQ-Admin permission model:
    - HQ Admin/ISSM: Full Control on ALL sites
    - Installation G-6: Full Control on their installation + all dir sites
    - Directorate groups: Scoped to own site only
    Breaks inheritance on each site and applies Azure AD group permissions.
.NOTES
    Requires: PnP.PowerShell module
    Run AFTER: 01, 02, 03 scripts
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$sitePrefix = $config.SharePoint.SitePrefix
$prefix = $config.AzureAD.GroupPrefix
$hubUrl = $config.MSC.HubSiteUrl

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - Permission Configuration" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

function Set-CWFSitePermission {
    param(
        [string]$SiteUrl,
        [string]$GroupName,
        [string]$PermissionLevel,  # "Full Control", "Edit", "Read", "Contribute"
        [string]$Context = ""
    )
    
    Write-Host "    [$PermissionLevel] $GroupName" -ForegroundColor $(
        switch ($PermissionLevel) {
            "Full Control" { "Red" }
            "Edit"         { "Blue" }
            "Contribute"   { "Cyan" }
            "Read"         { "Gray" }
            default        { "White" }
        }
    ) -NoNewline
    if ($Context) { Write-Host " ($Context)" -ForegroundColor DarkGray } else { Write-Host "" }
    
    if ($WhatIf) { return }
    
    try {
        # Resolve Azure AD group to ensure it exists
        $roleDefinition = $PermissionLevel
        
        # Add the group to the site with the specified permission level
        Set-PnPWebPermission -Identity $GroupName -AddRole $roleDefinition
    } catch {
        Write-Host "      [ERROR] $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Initialize-SitePermissions {
    param(
        [string]$SiteUrl,
        [string]$SiteName
    )
    
    Write-Host "`n  Site: $SiteName" -ForegroundColor Yellow
    Write-Host "  URL:  $SiteUrl" -ForegroundColor DarkGray
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would break inheritance and configure permissions" -ForegroundColor DarkYellow
        return
    }
    
    # Connect to site
    Connect-PnPOnline -Url $SiteUrl -Interactive
    
    # Break permission inheritance (keep existing permissions = false to start clean)
    try {
        # Check if already broken
        $web = Get-PnPWeb -Includes HasUniqueRoleAssignments
        if (-not $web.HasUniqueRoleAssignments) {
            Set-PnPWeb -BreakInheritance
            Write-Host "    [BREAK] Inheritance broken" -ForegroundColor DarkYellow
        } else {
            Write-Host "    [EXISTS] Already has unique permissions" -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "    [WARN] Could not break inheritance: $($_.Exception.Message)" -ForegroundColor DarkYellow
    }
}

# ═══════════════════════════════════════
# PHASE 1: MSC Hub Site Permissions
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 1: MSC Hub Site Permissions      │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘" -ForegroundColor Cyan

Initialize-SitePermissions -SiteUrl $hubUrl -SiteName "$sitePrefix-HUB"

# HQ groups on Hub
Set-CWFSitePermission -SiteUrl $hubUrl -GroupName "$prefix-ADMIN" -PermissionLevel "Full Control" -Context "HQ Admin"
Set-CWFSitePermission -SiteUrl $hubUrl -GroupName "$prefix-ISSM" -PermissionLevel "Edit" -Context "HQ ISSM"
Set-CWFSitePermission -SiteUrl $hubUrl -GroupName "$prefix-ANALYST" -PermissionLevel "Edit" -Context "HQ Analyst"
Set-CWFSitePermission -SiteUrl $hubUrl -GroupName "$prefix-AUDITOR" -PermissionLevel "Read" -Context "Auditor"
Set-CWFSitePermission -SiteUrl $hubUrl -GroupName "$prefix-SVC" -PermissionLevel "Full Control" -Context "Service Account"

# All Install G-6 get Read on Hub (for dashboard access)
Set-CWFSitePermission -SiteUrl $hubUrl -GroupName "$prefix-ALLINSTG6" -PermissionLevel "Read" -Context "All Install G-6 (dashboard)"

# ═══════════════════════════════════════
# PHASE 2: Installation Hub Permissions
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 2: Installation Hub Permissions  │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘" -ForegroundColor Cyan

foreach ($install in $config.Installations) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    $installG6Group = "$prefix-$($install.Code)-G6"
    
    Initialize-SitePermissions -SiteUrl $installUrl -SiteName "$sitePrefix-$($install.Code)"
    
    # HQ groups: Full Control everywhere
    Set-CWFSitePermission -SiteUrl $installUrl -GroupName "$prefix-ADMIN" -PermissionLevel "Full Control" -Context "HQ Admin"
    Set-CWFSitePermission -SiteUrl $installUrl -GroupName "$prefix-ISSM" -PermissionLevel "Full Control" -Context "HQ ISSM"
    Set-CWFSitePermission -SiteUrl $installUrl -GroupName "$prefix-ANALYST" -PermissionLevel "Edit" -Context "HQ Analyst"
    Set-CWFSitePermission -SiteUrl $installUrl -GroupName "$prefix-AUDITOR" -PermissionLevel "Read" -Context "Auditor"
    Set-CWFSitePermission -SiteUrl $installUrl -GroupName "$prefix-SVC" -PermissionLevel "Full Control" -Context "Service Account"
    
    # This installation's G-6: Full Control on install hub
    Set-CWFSitePermission -SiteUrl $installUrl -GroupName $installG6Group -PermissionLevel "Full Control" -Context "Install G-6"
    
    # Directorate coordinators at this installation: Read on install hub (dashboard access)
    foreach ($dir in $install.Directorates) {
        if (-not $dir.IsHQAdmin -and -not $dir.IsInstallG6) {
            $coordGroup = "$prefix-$($install.Code)-$($dir.Code)-Coord"
            Set-CWFSitePermission -SiteUrl $installUrl -GroupName $coordGroup -PermissionLevel "Read" -Context "Dir Coordinator dashboard"
        }
    }
}

# ═══════════════════════════════════════
# PHASE 3: Directorate Site Permissions
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 3: Directorate Site Permissions  │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘" -ForegroundColor Cyan

foreach ($install in $config.Installations) {
    $installG6Group = "$prefix-$($install.Code)-G6"
    
    foreach ($dir in $install.Directorates) {
        $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
        $dirPrefix = "$prefix-$($install.Code)-$($dir.Code)"
        
        Initialize-SitePermissions -SiteUrl $dirUrl -SiteName "$sitePrefix-$($install.Code)-$($dir.Code)"
        
        # HQ groups: Full Control everywhere
        Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$prefix-ADMIN" -PermissionLevel "Full Control" -Context "HQ Admin"
        Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$prefix-ISSM" -PermissionLevel "Full Control" -Context "HQ ISSM"
        Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$prefix-ANALYST" -PermissionLevel "Edit" -Context "HQ Analyst"
        Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$prefix-AUDITOR" -PermissionLevel "Read" -Context "Auditor"
        Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$prefix-SVC" -PermissionLevel "Full Control" -Context "Service Account"
        
        # Installation G-6: Full Control on ALL directorate sites at their installation
        Set-CWFSitePermission -SiteUrl $dirUrl -GroupName $installG6Group -PermissionLevel "Full Control" -Context "Install G-6 (compliance authority)"
        
        # Directorate-specific permissions
        if ($dir.IsHQAdmin) {
            # HQ Admin directorate (TACOM G-6) - staff group gets Edit
            Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$dirPrefix-Staff" -PermissionLevel "Edit" -Context "HQ G-6 staff"
        }
        elseif ($dir.IsInstallG6) {
            # Installation G-6 directorate - staff group gets Edit (they already have FC via install group)
            Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$dirPrefix-Staff" -PermissionLevel "Edit" -Context "Install G-6 staff"
        }
        else {
            # Standard consumer directorate
            Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$dirPrefix-Coord" -PermissionLevel "Edit" -Context "Dir CWF Coordinator"
            Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$dirPrefix-Supv" -PermissionLevel "Edit" -Context "Dir Supervisors"
            Set-CWFSitePermission -SiteUrl $dirUrl -GroupName "$dirPrefix-Personnel" -PermissionLevel "Contribute" -Context "Dir Personnel (self-service)"
            
            # SAAR Approver - custom permission (Edit on SAAR list only, Read on site)
            $saarGroup = "$dirPrefix-SAARAprv"
            Set-CWFSitePermission -SiteUrl $dirUrl -GroupName $saarGroup -PermissionLevel "Read" -Context "SAAR Approver (site-level read)"
            
            Write-Host "    [NOTE] SAAR Approver list-level Edit must be configured manually on CWF_SAARRequests list" -ForegroundColor DarkYellow
        }
    }
}

# ═══════════════════════════════════════
# PHASE 4: List-Level Permission Overrides
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 4: List-Level Overrides          │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

# Make enforcement/waiver lists READ-ONLY at installation hubs
# (HQ pushes data there but install G-6 should not edit)
foreach ($install in $config.Installations) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    $installG6Group = "$prefix-$($install.Code)-G6"
    
    Write-Host "  Install: $($install.Code) - Setting enforcement/waiver lists to read-only for Install G-6" -ForegroundColor Yellow
    
    if (-not $WhatIf) {
        Connect-PnPOnline -Url $installUrl -Interactive
        
        foreach ($listName in @("CWF_EnforcementActions", "CWF_ComplianceWaivers")) {
            try {
                $list = Get-PnPList -Identity $listName -ErrorAction SilentlyContinue
                if ($list) {
                    # Break list inheritance
                    Set-PnPList -Identity $listName -BreakRoleInheritance -CopyRoleAssignments
                    
                    # Remove Install G-6 Edit, add Read only
                    # Note: In practice you may need to use Set-PnPListPermission cmdlet
                    Write-Host "    [OVERRIDE] $listName - Install G-6 set to Read" -ForegroundColor DarkCyan
                }
            } catch {
                Write-Host "    [WARN] Could not override $listName permissions: $($_.Exception.Message)" -ForegroundColor DarkYellow
            }
        }
    }
}

# ═══════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════
Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  PERMISSION CONFIGURATION COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  Permission Model: Centralized HQ-Admin" -ForegroundColor White
Write-Host "  HQ Admin/ISSM:    Full Control on ALL sites" -ForegroundColor Red
Write-Host "  Install G-6:      Full Control at own installation" -ForegroundColor Blue
Write-Host "  Dir Coordinator:  Edit on own site + Read on install hub" -ForegroundColor Cyan
Write-Host "  Dir Personnel:    Contribute on own site only" -ForegroundColor Gray
Write-Host ""
Write-Host "  MANUAL STEP REQUIRED:" -ForegroundColor Yellow
Write-Host "  - Configure SAAR Approver list-level Edit on CWF_SAARRequests" -ForegroundColor Yellow
Write-Host "  - Verify enforcement/waiver lists are read-only at install hubs" -ForegroundColor Yellow
Write-Host ""
