<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 7: Apply Column Formatting
.DESCRIPTION
    Applies JSON column formatting to SharePoint list columns for:
    - Status pill badges (Synced=green, Pending=blue, Error=red)
    - Compliance score bars (green/yellow/red gradient)
    - Cert/Training status color coding
    - SAAR status workflow badges
    - Severity indicators on compliance flags
.NOTES
    Requires: PnP.PowerShell module
    Run AFTER: 03-Deploy-ListSchemas.ps1
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$sitePrefix = $config.SharePoint.SitePrefix
$hubUrl = $config.MSC.HubSiteUrl

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - Column Formatting" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

# ══════════════════════════════════════════════════════
# FORMAT DEFINITIONS (JSON column formatting)
# ══════════════════════════════════════════════════════

# ── Sync Status Pill ──
$formatSyncStatus = @'
{
  "$schema": "https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json",
  "elmType": "div",
  "style": {
    "display": "inline-block",
    "padding": "2px 12px",
    "border-radius": "12px",
    "font-size": "12px",
    "font-weight": "600",
    "white-space": "nowrap"
  },
  "attributes": {
    "class": {
      "operator": ":",
      "operands": [
        { "operator": "==", "operands": ["@currentField", "Synced"] },
        "sp-css-backgroundColor-successBackground sp-css-color-successFont",
        {
          "operator": ":",
          "operands": [
            { "operator": "==", "operands": ["@currentField", "Pending"] },
            "sp-css-backgroundColor-warningBackground sp-css-color-warningFont",
            {
              "operator": ":",
              "operands": [
                { "operator": "==", "operands": ["@currentField", "Validation Error"] },
                "sp-css-backgroundColor-errorBackground sp-css-color-errorFont",
                "sp-css-backgroundColor-errorBackground sp-css-color-errorFont"
              ]
            }
          ]
        }
      ]
    }
  },
  "txtContent": "@currentField"
}
'@

# ── Cert Status Pill ──
$formatCertStatus = @'
{
  "$schema": "https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json",
  "elmType": "div",
  "style": {
    "display": "inline-block",
    "padding": "2px 12px",
    "border-radius": "12px",
    "font-size": "12px",
    "font-weight": "600"
  },
  "attributes": {
    "class": {
      "operator": ":",
      "operands": [
        { "operator": "==", "operands": ["@currentField", "Current"] },
        "sp-css-backgroundColor-successBackground sp-css-color-successFont",
        {
          "operator": ":",
          "operands": [
            { "operator": "==", "operands": ["@currentField", "Expiring"] },
            "sp-css-backgroundColor-warningBackground sp-css-color-warningFont",
            "sp-css-backgroundColor-errorBackground sp-css-color-errorFont"
          ]
        }
      ]
    }
  },
  "txtContent": "@currentField"
}
'@

# ── SAAR Status Pill ──
$formatSAARStatus = @'
{
  "$schema": "https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json",
  "elmType": "div",
  "style": {
    "display": "inline-flex",
    "align-items": "center",
    "gap": "6px",
    "padding": "2px 12px",
    "border-radius": "12px",
    "font-size": "12px",
    "font-weight": "600"
  },
  "attributes": {
    "class": {
      "operator": ":",
      "operands": [
        { "operator": "==", "operands": ["@currentField", "Approved"] },
        "sp-css-backgroundColor-successBackground sp-css-color-successFont",
        {
          "operator": ":",
          "operands": [
            { "operator": "==", "operands": ["@currentField", "Pending HQ Review"] },
            "sp-css-backgroundColor-warningBackground sp-css-color-warningFont",
            {
              "operator": ":",
              "operands": [
                { "operator": "==", "operands": ["@currentField", "Submitted"] },
                "sp-css-backgroundColor-BgLightBlue sp-field-fontSizeSmall",
                "sp-css-backgroundColor-errorBackground sp-css-color-errorFont"
              ]
            }
          ]
        }
      ]
    }
  },
  "children": [
    {
      "elmType": "span",
      "txtContent": {
        "operator": ":",
        "operands": [
          { "operator": "==", "operands": ["@currentField", "Approved"] },
          "✓",
          {
            "operator": ":",
            "operands": [
              { "operator": "==", "operands": ["@currentField", "Pending HQ Review"] },
              "⏳",
              {
                "operator": ":",
                "operands": [
                  { "operator": "==", "operands": ["@currentField", "Returned"] },
                  "↩",
                  ""
                ]
              }
            ]
          }
        ]
      }
    },
    { "elmType": "span", "txtContent": "@currentField" }
  ]
}
'@

# ── Compliance Score Bar ──
$formatComplianceScore = @'
{
  "$schema": "https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json",
  "elmType": "div",
  "style": {
    "display": "flex",
    "align-items": "center",
    "gap": "8px"
  },
  "children": [
    {
      "elmType": "div",
      "style": {
        "width": "80px",
        "height": "8px",
        "background-color": "#f3f2f1",
        "border-radius": "4px",
        "overflow": "hidden"
      },
      "children": [
        {
          "elmType": "div",
          "style": {
            "width": {
              "operator": "+",
              "operands": [
                { "operator": "toString()", "operands": ["@currentField"] },
                "%"
              ]
            },
            "height": "100%",
            "border-radius": "4px",
            "background-color": {
              "operator": ":",
              "operands": [
                { "operator": ">=", "operands": ["@currentField", 85] },
                "#107c10",
                {
                  "operator": ":",
                  "operands": [
                    { "operator": ">=", "operands": ["@currentField", 70] },
                    "#c8ab37",
                    "#a4262c"
                  ]
                }
              ]
            }
          }
        }
      ]
    },
    {
      "elmType": "span",
      "style": {
        "font-weight": "600",
        "font-size": "12px",
        "color": {
          "operator": ":",
          "operands": [
            { "operator": ">=", "operands": ["@currentField", 85] },
            "#107c10",
            {
              "operator": ":",
              "operands": [
                { "operator": ">=", "operands": ["@currentField", 70] },
                "#8a6914",
                "#a4262c"
              ]
            }
          ]
        }
      },
      "txtContent": {
        "operator": "+",
        "operands": [
          { "operator": "toString()", "operands": ["@currentField"] },
          "%"
        ]
      }
    }
  ]
}
'@

# ── Severity Badge (Compliance Flags) ──
$formatSeverity = @'
{
  "$schema": "https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json",
  "elmType": "div",
  "style": {
    "display": "inline-block",
    "padding": "2px 12px",
    "border-radius": "4px",
    "font-size": "12px",
    "font-weight": "700",
    "text-transform": "uppercase",
    "letter-spacing": "0.5px"
  },
  "attributes": {
    "class": {
      "operator": ":",
      "operands": [
        { "operator": "==", "operands": ["@currentField", "Critical"] },
        "sp-css-backgroundColor-errorBackground sp-css-color-errorFont",
        {
          "operator": ":",
          "operands": [
            { "operator": "==", "operands": ["@currentField", "High"] },
            "sp-css-backgroundColor-warningBackground sp-css-color-warningFont",
            {
              "operator": ":",
              "operands": [
                { "operator": "==", "operands": ["@currentField", "Medium"] },
                "sp-css-backgroundColor-BgLightBlue sp-field-fontSizeSmall",
                "sp-css-backgroundColor-successBackground sp-css-color-successFont"
              ]
            }
          ]
        }
      ]
    }
  },
  "txtContent": "@currentField"
}
'@

# ── Enforcement Action Status ──
$formatEnforcementStatus = @'
{
  "$schema": "https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json",
  "elmType": "div",
  "style": {
    "display": "inline-flex",
    "align-items": "center",
    "gap": "4px",
    "padding": "2px 12px",
    "border-radius": "12px",
    "font-size": "12px",
    "font-weight": "600"
  },
  "attributes": {
    "class": {
      "operator": ":",
      "operands": [
        { "operator": "==", "operands": ["@currentField", "Active"] },
        "sp-css-backgroundColor-errorBackground sp-css-color-errorFont",
        {
          "operator": ":",
          "operands": [
            { "operator": "==", "operands": ["@currentField", "Pending Resolution"] },
            "sp-css-backgroundColor-warningBackground sp-css-color-warningFont",
            {
              "operator": ":",
              "operands": [
                { "operator": "==", "operands": ["@currentField", "Resolved"] },
                "sp-css-backgroundColor-successBackground sp-css-color-successFont",
                "sp-css-backgroundColor-BgLightBlue sp-field-fontSizeSmall"
              ]
            }
          ]
        }
      ]
    }
  },
  "txtContent": "@currentField"
}
'@

# ══════════════════════════════════════════════════════
# FORMAT APPLICATION MAP
# ══════════════════════════════════════════════════════

$formatMap = @(
    # Directorate transactional lists
    @{ List="CWF_Personnel";        Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="Dir" }
    @{ List="CWF_MyCertifications"; Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="Dir" }
    @{ List="CWF_MyCertifications"; Column="CertStatus";                 Format=$formatCertStatus;         SiteType="Dir" }
    @{ List="CWF_TrainingRecords";  Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="Dir" }
    @{ List="CWF_SAARRequests";     Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="Dir" }
    @{ List="CWF_SAARRequests";     Column="SAARStatus";                 Format=$formatSAARStatus;         SiteType="Dir" }
    @{ List="CWF_MyWorkRoles";      Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="Dir" }
    # Compliance Status (all site types)
    @{ List="CWF_ComplianceStatus"; Column="OverallScore";               Format=$formatComplianceScore;    SiteType="All" }
    @{ List="CWF_ComplianceStatus"; Column="CertComplianceStatus";       Format=$formatCertStatus;         SiteType="All" }
    @{ List="CWF_ComplianceStatus"; Column="TrainingComplianceStatus";   Format=$formatCertStatus;         SiteType="All" }
    # Installation Hub lists
    @{ List="CWF_ComplianceFlags";  Column="Severity";                   Format=$formatSeverity;           SiteType="InstallHub" }
    @{ List="CWF_ComplianceFlags";  Column="FlagStatus";                 Format=$formatSyncStatus;         SiteType="InstallHub" }
    @{ List="CWF_ComplianceFlags";  Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="InstallHub" }
    @{ List="CWF_WaiverRequests";   Column="WaiverReqStatus";            Format=$formatSAARStatus;         SiteType="InstallHub" }
    @{ List="CWF_WaiverRequests";   Column="DV_SyncStatus";              Format=$formatSyncStatus;         SiteType="InstallHub" }
    # Enforcement/Waiver (Hub + Install)
    @{ List="CWF_EnforcementActions"; Column="ActionStatus";             Format=$formatEnforcementStatus;  SiteType="HubInstall" }
    @{ List="CWF_ComplianceWaivers";  Column="WaiverStatus";             Format=$formatCertStatus;         SiteType="HubInstall" }
    # Hub only
    @{ List="SyncErrorLog";         Column="Resolution";                 Format=$formatSyncStatus;         SiteType="Hub" }
)

# ══════════════════════════════════════════════════════
# APPLICATION
# ══════════════════════════════════════════════════════

function Apply-ColumnFormat {
    param(
        [string]$SiteUrl,
        [string]$ListName,
        [string]$ColumnName,
        [string]$FormatJson
    )
    
    if ($WhatIf) {
        Write-Host "      [WhatIf] Would format $ListName/$ColumnName" -ForegroundColor DarkYellow
        return
    }
    
    try {
        $list = Get-PnPList -Identity $ListName -ErrorAction SilentlyContinue
        if (-not $list) {
            Write-Host "      [SKIP] List not found: $ListName" -ForegroundColor DarkGray
            return
        }
        
        $field = Get-PnPField -List $ListName -Identity $ColumnName -ErrorAction SilentlyContinue
        if (-not $field) {
            Write-Host "      [SKIP] Column not found: $ColumnName" -ForegroundColor DarkGray
            return
        }
        
        Set-PnPField -List $ListName -Identity $ColumnName -Values @{
            CustomFormatter = $FormatJson
        }
        
        Write-Host "      [FORMATTED] $ListName / $ColumnName" -ForegroundColor Green
    } catch {
        Write-Host "      [ERROR] $ListName / $ColumnName - $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ── Apply to MSC Hub ──
Write-Host "`n  MSC Hub: $hubUrl" -ForegroundColor Yellow
if (-not $WhatIf) { Connect-PnPOnline -Url $hubUrl -Interactive }
foreach ($fmt in ($formatMap | Where-Object { $_.SiteType -in @("All","Hub","HubInstall") })) {
    Apply-ColumnFormat -SiteUrl $hubUrl -ListName $fmt.List -ColumnName $fmt.Column -FormatJson $fmt.Format
}

# ── Apply to Installation Hubs ──
foreach ($install in $config.Installations) {
    $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
    Write-Host "`n  Install Hub: $($install.Code)" -ForegroundColor Yellow
    if (-not $WhatIf) { Connect-PnPOnline -Url $installUrl -Interactive }
    foreach ($fmt in ($formatMap | Where-Object { $_.SiteType -in @("All","InstallHub","HubInstall") })) {
        Apply-ColumnFormat -SiteUrl $installUrl -ListName $fmt.List -ColumnName $fmt.Column -FormatJson $fmt.Format
    }
}

# ── Apply to Directorate Sites ──
foreach ($install in $config.Installations) {
    foreach ($dir in $install.Directorates) {
        $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
        Write-Host "`n  Dir Site: $($install.Code)-$($dir.Code)" -ForegroundColor Yellow
        if (-not $WhatIf) { Connect-PnPOnline -Url $dirUrl -Interactive }
        foreach ($fmt in ($formatMap | Where-Object { $_.SiteType -in @("All","Dir") })) {
            Apply-ColumnFormat -SiteUrl $dirUrl -ListName $fmt.List -ColumnName $fmt.Column -FormatJson $fmt.Format
        }
    }
}

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  COLUMN FORMATTING COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Green
